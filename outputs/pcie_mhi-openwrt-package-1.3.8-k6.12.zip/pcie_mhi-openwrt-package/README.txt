Quectel PCIe MHI driver OpenWrt package wrapper
================================================

This is an experimental OpenWrt kernel package wrapper around Quectel's
publicly mirrored PCIe MHI driver V1.3.8. It is intended for a matching
OpenWrt 25.12.6 mediatek/filogic SDK (kernel 6.12.112).

The upstream MHI stack and this driver cannot own the modem simultaneously.
Do not install/load this package while mhi_pci_generic is bound. Build it
first, then plan the driver swap on the router.

Build on an x86_64 Linux host:
  1. Download/extract the OpenWrt 25.12.6 mediatek/filogic SDK.
  2. Copy this directory into SDK/package/kernel/pcie_mhi.
  3. Copy the contents of the Quectel driver archive's pcie_mhi/ directory
     into SDK/package/kernel/pcie_mhi/src/ (controllers/, core/, devices/,
     log/, Makefile, ReleaseNote.txt, README).
  4. Run: make defconfig
  5. Run: make package/kernel/pcie_mhi/compile V=s
  6. Install the resulting kmod-pcie_mhi APK only if compilation succeeds
     and the router's exact kernel ABI matches the SDK.

The V1.3.8 release notes do not certify Linux 6.12.112 compatibility. This
wrapper has not been built or tested here. The module package may need source
fixes for the 6.12 kernel API before it compiles.
