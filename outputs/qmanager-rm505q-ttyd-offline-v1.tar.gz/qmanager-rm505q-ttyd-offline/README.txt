QManager RM505Q-AE offline web-console fix

This package contains the official ttyd v1.7.7 ARMv7 static binary and an
installer that places it at /usrdata/qmanager/console/ttyd, then enables and
starts QManager's existing qmanager-console systemd service.

No radio, APN, PCIe, MBIM, or router networking settings are changed.
