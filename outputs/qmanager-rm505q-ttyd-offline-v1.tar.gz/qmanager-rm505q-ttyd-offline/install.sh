#!/bin/sh
# Offline web-console installer for the RM505Q-AE QManager deployment.
set -eu

base_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ttyd_src="$base_dir/ttyd.armhf"
console_dir=/usrdata/qmanager/console
ttyd_dst="$console_dir/ttyd"
unit=/lib/systemd/system/qmanager-console.service

[ -x /bin/systemctl ] || { echo 'systemd is unavailable'; exit 1; }
[ -x "$ttyd_src" ] || { echo "Missing executable: $ttyd_src"; exit 1; }
[ -f "$unit" ] || { echo "Missing QManager console unit: $unit"; exit 1; }
[ -f "$console_dir/console.sh" ] || { echo "Missing QManager console script"; exit 1; }

install -d -o root -g root -m 0755 "$console_dir"
install -o root -g root -m 0755 "$ttyd_src" "$ttyd_dst"
chmod 0755 "$console_dir/console.sh"

systemctl daemon-reload
systemctl enable qmanager-console.service
systemctl restart qmanager-console.service
sleep 2

if systemctl is-active --quiet qmanager-console.service; then
    echo 'QManager web console installed and running on 127.0.0.1:8080.'
else
    echo 'ttyd was installed but qmanager-console did not start.' >&2
    systemctl status qmanager-console.service --no-pager >&2 || true
    exit 1
fi
