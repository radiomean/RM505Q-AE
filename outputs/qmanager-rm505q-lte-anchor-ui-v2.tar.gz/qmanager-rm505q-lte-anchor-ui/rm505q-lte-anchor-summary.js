/*
 * RM505Q-AE / QManager display-only enhancement.
 *
 * On some SDX55 firmware builds, NSA operation exposes the LTE anchor's
 * serving-cell measurements through AT+QENG, but exposes only NR5G values
 * through the four-port QRSRP/QRSRQ/QSINR commands.  QManager already caches
 * QENG in fetch_data.sh.  This small page enhancement presents those existing
 * LTE values without pretending they are antenna-port measurements.
 */
(function () {
  'use strict';

  var ID = 'rm505q-lte-anchor-summary';
  var endpoint = '/cgi-bin/quecmanager/at_cmd/fetch_data.sh';

  function value(v, suffix) {
    return (v === null || v === undefined || v === '') ? '—' : String(v) + (suffix || '');
  }

  function connected(data) {
    /*
     * The RM505 occasionally prefixes a perfectly valid NSA QENG reply with
     * "servingcell","NOCONN".  The poller still extracts the LTE/NR records,
     * so use the presence of an LTE RSRP rather than the transient state flag.
     */
    return data && data.network && data.network.type === '5G-NSA' &&
      data.lte && data.lte.rsrp !== null && data.lte.rsrp !== undefined;
  }

  function ensurePanel() {
    var panel = document.getElementById(ID);
    if (panel) return panel;

    panel = document.createElement('section');
    panel.id = ID;
    panel.setAttribute('aria-live', 'polite');
    panel.style.cssText = [
      'position:fixed', 'z-index:2147483647', 'right:18px', 'bottom:18px',
      'max-width:min(560px,calc(100vw - 36px))', 'margin:0', 'padding:16px',
      'box-shadow:0 12px 32px rgba(0,0,0,.28)', 'border:1px solid rgba(148,163,184,.45)',
      'border-left:4px solid #60a5fa', 'border-radius:10px',
      'background:rgba(59,130,246,.08)', 'color:inherit', 'font:inherit'
    ].join(';');

    /* The exported Next.js build does not provide a stable <main> root. */
    document.body.appendChild(panel);
    return panel;
  }

  function render(data) {
    var old = document.getElementById(ID);
    if (!connected(data)) {
      if (old) old.remove();
      return;
    }

    var lte = data.lte;
    var panel = ensurePanel();
    panel.innerHTML =
      '<div style="font-weight:700;font-size:1.05em;margin-bottom:6px">LTE anchor (5G NSA)</div>' +
      '<div style="margin-bottom:9px;opacity:.86">' +
        'Live aggregate LTE serving-cell measurements from the RM505Q-AE. ' +
        'They are not per-antenna values.' +
      '</div>' +
      '<div style="display:flex;flex-wrap:wrap;gap:9px 20px;font-variant-numeric:tabular-nums">' +
        '<span><b>Band:</b> ' + value(lte.band) + '</span>' +
        '<span><b>RSRP:</b> ' + value(lte.rsrp, ' dBm') + '</span>' +
        '<span><b>RSRQ:</b> ' + value(lte.rsrq, ' dB') + '</span>' +
        '<span><b>SINR:</b> ' + value(lte.sinr, ' dB') + '</span>' +
        '<span><b>RSSI:</b> ' + value(lte.rssi, ' dBm') + '</span>' +
        '<span><b>PCI:</b> ' + value(lte.pci) + '</span>' +
        '<span><b>EARFCN:</b> ' + value(lte.earfcn) + '</span>' +
      '</div>';
  }

  function refresh() {
    fetch(endpoint, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (response) {
        if (!response.ok) throw new Error('status ' + response.status);
        return response.json();
      })
      .then(render)
      .catch(function () { /* Leave the normal QManager page untouched. */ });
  }

  function start() {
    refresh();
    window.setInterval(refresh, 5000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
}());
