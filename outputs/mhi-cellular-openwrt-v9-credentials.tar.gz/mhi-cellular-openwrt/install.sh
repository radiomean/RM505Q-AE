#!/bin/sh
set -eu

base_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

cp "$base_dir/files/usr/bin/quectel-CM" /usr/bin/quectel-CM
cp "$base_dir/files/usr/bin/mhi-at" /usr/bin/mhi-at
cp "$base_dir/files/usr/bin/mhi-query" /usr/bin/mhi-query
cp "$base_dir/files/usr/libexec/quectel-mhi-dial" /usr/libexec/quectel-mhi-dial
cp "$base_dir/files/usr/libexec/quectel-mhi-control" /usr/libexec/quectel-mhi-control
cp "$base_dir/files/usr/libexec/quectel-mhi-scan" /usr/libexec/quectel-mhi-scan
cp "$base_dir/files/etc/init.d/quectel-mhi" /etc/init.d/quectel-mhi
if [ ! -f /etc/config/quectel-mhi ]; then
	cp "$base_dir/files/etc/config/quectel-mhi" /etc/config/quectel-mhi
fi
mkdir -p /www/luci-static/resources/view/quectel-mhi /usr/share/luci/menu.d /usr/share/rpcd/acl.d /usr/share/rpcd/ucode
cp "$base_dir/files/www/luci-static/resources/view/quectel-mhi/config.js" /www/luci-static/resources/view/quectel-mhi/config.js
cp "$base_dir/files/www/luci-static/resources/view/quectel-mhi/controls.js" /www/luci-static/resources/view/quectel-mhi/controls.js
cp "$base_dir/files/usr/share/luci/menu.d/luci-app-quectel-mhi.json" /usr/share/luci/menu.d/luci-app-quectel-mhi.json
cp "$base_dir/files/usr/share/rpcd/acl.d/luci-app-quectel-mhi.json" /usr/share/rpcd/acl.d/luci-app-quectel-mhi.json
cp "$base_dir/files/usr/share/rpcd/ucode/quectel-mhi.uc" /usr/share/rpcd/ucode/quectel-mhi.uc
chmod 755 /usr/bin/quectel-CM /usr/bin/mhi-at /usr/bin/mhi-query /usr/libexec/quectel-mhi-dial /usr/libexec/quectel-mhi-control /usr/libexec/quectel-mhi-scan /etc/init.d/quectel-mhi
chmod 644 /usr/share/rpcd/ucode/quectel-mhi.uc
chmod 644 /etc/config/quectel-mhi

/etc/init.d/quectel-mhi enable
/etc/init.d/rpcd restart
sync

echo 'Installed. Existing network and firewall settings were deliberately preserved.'
