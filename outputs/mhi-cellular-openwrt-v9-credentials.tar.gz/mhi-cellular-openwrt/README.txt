MHI Cellular LuCI integration for BPI-R4 / RM505Q-AE

This bundle assumes the custom pcie_mhi driver and its 180-second delayed
loader are already installed and working.

It installs or updates:
  - /usr/bin/quectel-CM, built for OpenWrt aarch64/musl
  - a procd service that waits for the MHI QMI/network devices
  - a LuCI connection page with APN, username, password and authentication

Existing OpenWrt networking and firewall configuration is preserved.

LuCI pages under Services provide both the connection/status dashboard and a
separate Quectel MHI Controls page. The controls page supports RAT selection,
LTE/5G band lists, network scans, PLMN selection, carrier aggregation queries
and guarded LTE cell locking. Every connection-disrupting action asks for
confirmation. Cell locking is firmware-dependent: inspect the capability and
current lock before changing it, and record a known-good setting first.

Installation on the router:
  cd /tmp
  tar -xzf mhi-cellular-openwrt.tar.gz
  cd mhi-cellular-openwrt
  ./install.sh
  reboot

After boot, allow the existing 180-second MHI driver delay plus about one
minute for the cellular service to establish the MBIM data call. Then open
LuCI: Services > Quectel MHI.

To change credentials later, use LuCI: Services > Quectel MHI. The equivalent
command-line configuration is:
  uci set quectel-mhi.main.apn='your-apn'
  uci set quectel-mhi.main.username='your-username'
  uci set quectel-mhi.main.password='your-password'
  uci set quectel-mhi.main.auth='pap'
  uci commit quectel-mhi
  /etc/init.d/quectel-mhi restart
