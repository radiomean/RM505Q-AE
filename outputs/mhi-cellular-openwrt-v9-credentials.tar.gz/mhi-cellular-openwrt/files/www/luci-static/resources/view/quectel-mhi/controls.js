'use strict';
'require view';
'require rpc';
'require ui';

const callControl = rpc.declare({
	object: 'luci.quectel-mhi', method: 'control',
	params: [ 'action', 'value', 'value2' ], expect: { '': {} }
});

const callScanStatus = rpc.declare({
	object: 'luci.quectel-mhi', method: 'scan_status', expect: { '': {} }
});

function select(id, entries) {
	return E('select', { 'id': id, 'class': 'cbi-input-select' }, entries.map(function(entry) {
		return E('option', { 'value': entry[0] }, [ entry[1] ]);
	}));
}

function field(id, placeholder) {
	return E('input', { 'id': id, 'class': 'cbi-input-text', 'type': 'text', 'placeholder': placeholder });
}

function responseBox() {
	return E('pre', { 'id': 'mhi-control-output', 'style': 'white-space: pre-wrap; min-height: 4em; margin-top: 1em' }, [
		_('Select an action. The modem reply will appear here.')
	]);
}

function result(output, success) {
	const box = document.getElementById('mhi-control-output');
	if (box)
		box.textContent = output || (success ? _('Command sent.') : _('No response from the modem.'));
	ui.addNotification(null, E('p', {}, [ success ? _('Modem action completed.') : _('Modem action failed.') ]), success ? 'info' : 'danger');
}

const actionMeaning = {
	mode: _('Changes the preferred radio technology. The modem will re-register using this choice.'),
	nr_disable: _('Changes whether 5G standalone or non-standalone operation is permitted.'),
	rat_order: _('Changes the order in which the modem looks for supported radio technologies.'),
	lte_bands: _('Replaces the permitted 4G LTE band list.'),
	nr_bands: _('Replaces the permitted 5G standalone band list.'),
	nsa_bands: _('Replaces the permitted 5G non-standalone band list.'),
	operator_auto: _('Returns operator selection to automatic.'),
	operator_manual: _('Requests the specified mobile network by its PLMN identifier.'),
	scan_start: _('Starts a full visible-network scan in the background.'),
	lte_lock: _('Pins LTE service to the specified channel (EARFCN) and physical cell ID.'),
	lte_unlock: _('Releases the LTE channel/cell pin.'),
	reset_radio: _('Restarts the modem radio stack; it will need time to re-register.')
};

function run(action, getValue, getValue2, warning) {
	return function(ev) {
		ev.preventDefault();
		if (warning && !window.confirm(warning))
			return;
		const value = getValue ? getValue() : '';
		const value2 = getValue2 ? getValue2() : '';
		result((actionMeaning[action] ? actionMeaning[action] + '\n\n' : '') + _('Working…'), true);
		callControl(action, value, value2).then(function(reply) {
			result(reply.output, reply.ok);
		}).catch(function(err) { result(String(err), false); });
	};
}

function button(label, action, value, value2, warning, cls) {
	return E('button', {
		'class': 'btn cbi-button ' + (cls || 'cbi-button-action'),
		'click': run(action, value, value2, warning)
	}, [ label ]);
}

function section(title, description, children) {
	return E('div', { 'class': 'cbi-section' }, [
		E('h3', {}, [ title ]), E('p', { 'class': 'cbi-section-descr' }, [ description ])
	].concat(children));
}

function row(title, content, description) {
	return E('div', { 'class': 'cbi-value' }, [
		E('label', { 'class': 'cbi-value-title' }, [ title ]),
		E('div', { 'class': 'cbi-value-field' }, [ content, description ? E('div', { 'class': 'cbi-value-description' }, [ description ]) : '' ])
	]);
}

const dropWarning = _('This will interrupt the cellular data connection while the modem re-registers. Continue?');

return view.extend({
	render: function() {
		const mode = select('mhi-mode', [
			[ 'AUTO', _('Automatic (all supported RATs)') ], [ 'LTE', _('4G / LTE only') ],
			[ 'NR5G', _('5G / NR only') ], [ 'LTE:NR5G', _('4G + 5G') ],
			[ 'WCDMA:LTE:NR5G', _('3G + 4G + 5G') ]
		]);
		const nr = select('mhi-nr-disable', [ [ '0', _('Allow 5G SA and NSA') ], [ '1', _('Disable 5G SA') ], [ '2', _('Disable 5G NSA') ] ]);
		const order = select('mhi-rat-order', [
			[ 'NR5G:LTE:WCDMA', _('Prefer 5G, then 4G') ], [ 'LTE:NR5G:WCDMA', _('Prefer 4G, then 5G') ],
			[ 'LTE:WCDMA:NR5G', _('Prefer 4G, then 3G, then 5G') ], [ 'NR5G:LTE', _('5G then 4G only') ], [ 'LTE:NR5G', _('4G then 5G only') ]
		]);
		const lteBands = field('mhi-lte-bands', '1:3:7:20');
		const nrBands = field('mhi-nr-bands', '1:3:28:78');
		const nsaBands = field('mhi-nsa-bands', '78');
		const plmn = field('mhi-plmn', '23420');
		const earfcn = field('mhi-earfcn', 'e.g. 1300');
		const pci = field('mhi-pci', '0–1007');

		const scanResult = E('pre', { 'id': 'mhi-scan-output', 'style': 'white-space: pre-wrap; margin-top: 1em' }, [ _('No scan result loaded.') ]);
		const showScan = function(ev) {
			ev.preventDefault();
			callScanStatus().then(function(reply) { scanResult.textContent = reply.output || _('No scan result.'); });
		};

		return E('div', {}, [
			E('h2', {}, [ _('Quectel MHI Controls') ]),
			E('p', {}, [ _('These controls use a limited, validated set of modem commands. Changes to radio mode, bands, operator or locking can disconnect cellular until the modem re-registers.') ]),
			section(_('Radio mode'), _('Choose which radio access technologies the modem is allowed to use.'), [
				row(_('Preferred mode'), E('div', {}, [ mode, ' ', button(_('Apply mode'), 'mode', () => mode.value, null, dropWarning) ])),
				row(_('5G operation'), E('div', {}, [ nr, ' ', button(_('Apply 5G setting'), 'nr_disable', () => nr.value, null, dropWarning) ])),
				row(_('Acquisition order'), E('div', {}, [ order, ' ', button(_('Apply order'), 'rat_order', () => order.value, null, dropWarning) ]))
			]),
			section(_('Band selection'), _('Enter colon-separated modem band numbers, for example 1:3:7:20. Restricting bands can leave the modem with no service; use the status page to record the working bands first.'), [
				row(_('4G LTE bands'), E('div', {}, [ lteBands, ' ', button(_('Set LTE bands'), 'lte_bands', () => lteBands.value, null, dropWarning) ])),
				row(_('5G SA NR bands'), E('div', {}, [ nrBands, ' ', button(_('Set 5G SA bands'), 'nr_bands', () => nrBands.value, null, dropWarning) ])),
				row(_('5G NSA NR bands'), E('div', {}, [ nsaBands, ' ', button(_('Set 5G NSA bands'), 'nsa_bands', () => nsaBands.value, null, dropWarning) ]))
			]),
			section(_('Operators and scan'), _('A network scan takes up to three minutes and continues in the background. Manual selection expects a five- or six-digit PLMN (iD/Three UK is 23420).'), [
				row(_('Available networks'), E('div', {}, [ button(_('Start network scan'), 'scan_start', null, null, dropWarning), ' ', E('button', { 'class': 'btn cbi-button cbi-button-action', 'click': showScan }, [ _('Show scan result') ]), scanResult ])),
				row(_('Operator'), E('div', {}, [ button(_('Select automatically'), 'operator_auto', null, null, dropWarning), ' ', plmn, ' ', button(_('Select PLMN'), 'operator_manual', () => plmn.value, null, dropWarning) ]))
			]),
			section(_('Tower / cell locking (advanced)'), _('Cell locking is modem/firmware-dependent. Check support and copy the LTE EARFCN and PCI from the serving-cell or scan output before applying a lock. A bad lock can remove service.'), [
				row(_('Capability and current state'), E('div', {}, [ button(_('Check locking support'), 'lock_support'), ' ', button(_('Show current lock'), 'lock_status') ])),
				row(_('LTE cell lock'), E('div', {}, [ earfcn, ' ', pci, ' ', button(_('Lock LTE cell'), 'lte_lock', () => earfcn.value, () => pci.value, _('This pins the modem to this LTE EARFCN and PCI and may remove service. Continue?'), 'cbi-button-negative') ])),
				row(_('Release LTE lock'), button(_('Release LTE cell lock'), 'lte_unlock', null, null, dropWarning, 'cbi-button-negative'))
			]),
			section(_('Diagnostics and recovery'), _('These actions only query the modem, except Reset radio which restarts its radio stack.'), [
				row(_('Live queries'), E('div', {}, [ button(_('Serving cell'), 'serving_cell'), ' ', button(_('Carrier aggregation'), 'aggregation') ])),
				row(_('Radio reset'), button(_('Reset modem radio'), 'reset_radio', null, null, _('This restarts the modem radio and will interrupt cellular for several minutes. Continue?'), 'cbi-button-negative'))
			]),
			responseBox()
		]);
	}
});
