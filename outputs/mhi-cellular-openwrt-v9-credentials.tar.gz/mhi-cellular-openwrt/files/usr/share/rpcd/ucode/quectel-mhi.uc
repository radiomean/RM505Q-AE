#!/usr/bin/env ucode
'use strict';

import { popen, access } from 'fs';

function query(command) {
	let proc = popen(`/usr/bin/mhi-query /dev/mhi_DUN '${command}' 2>/dev/null`, 'r');

	if (!proc)
		return null;

	let output = proc.read('all');
	let status = proc.close();

	if (status != 0 || !output)
		return null;

	return trim(output);
}

function run_control(action, value, value2) {
	if (!match(action, /^[a-z_]+$/) || !access('/dev/mhi_DUN'))
		return { ok: false, output: 'Modem is not ready or action is not allowed.' };

	value ??= '';
	value2 ??= '';
	if (!match(value, /^[A-Za-z0-9:]*$/) || !match(value2, /^[0-9]*$/))
		return { ok: false, output: 'Invalid value.' };

	let proc = popen(`/usr/libexec/quectel-mhi-control ${action} ${value} ${value2} 2>&1`, 'r');
	let output = proc?.read('all') || '';
	let status = proc?.close();

	return { ok: status == 0, output: trim(output) || (status == 0 ? 'Command sent.' : 'The modem rejected this setting.') };
}

function scan_status() {
	let proc = popen('cat /tmp/quectel-mhi-network-scan.log 2>/dev/null', 'r');
	let output = proc?.read('all') || '';
	proc?.close();
	return { output: trim(output) || 'No scan has been run yet.' };
}

const methods = {
	status: {
		call: function() {
			return {
				available: access('/dev/mhi_DUN'),
				identity: query('ATI'),
				sim: query('AT+CPIN?'),
				registration: query('AT+CEREG?'),
				network: query('AT+QNWINFO'),
				signal: query('AT+QCSQ'),
				serving_cell: query('AT+QENG="servingcell"'),
				carrier_aggregation: query('AT+QCAINFO'),
				pdp_contexts: query('AT+CGDCONT?'),
				pdp_activity: query('AT+CGACT?'),
			mode_preference: query('AT+QNWPREFCFG="mode_pref"'),
			lte_band_preference: query('AT+QNWPREFCFG="lte_band"'),
			nr5g_band_preference: query('AT+QNWPREFCFG="nr5g_band"'),
			nsa_nr5g_band_preference: query('AT+QNWPREFCFG="nsa_nr5g_band"'),
			nr5g_disable_mode: query('AT+QNWPREFCFG="nr5g_disable_mode"'),
			network_scan_mode: query('AT+QCFG="nwscanmode"'),
				pcie_mode: query('AT+QCFG="pcie/mode"'),
				pcie_mbim: query('AT+QCFG="pcie_mbim"'),
				mbn_profiles: query('AT+QMBNCFG="list"')
			};
		}
	},
	scan_status: {
		call: function() { return scan_status(); }
	},
	control: {
		call: function(req) {
			let action = req.args?.action || '';
			if (action == 'scan_start') {
				if (!access('/dev/mhi_DUN'))
					return { ok: false, output: 'Modem is not ready.' };
				popen('/usr/libexec/quectel-mhi-scan >/dev/null 2>&1 &', 'r')?.close();
				return { ok: true, output: 'Network scan started. It can take up to three minutes; use Show scan result afterwards.' };
			}
			return run_control(action, req.args?.value, req.args?.value2);
		}
	}
};

return { 'luci.quectel-mhi': methods };
