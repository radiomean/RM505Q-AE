'use strict';
'require view';
'require form';
'require rpc';

const callServiceList = rpc.declare({
	object: 'service',
	method: 'list',
	params: [ 'name' ],
	expect: { '': {} }
});

const callInterfaceStatus = rpc.declare({
	object: 'network.interface',
	method: 'status',
	params: [ 'interface' ],
	expect: { '': {} }
});

return view.extend({
	load: function() {
		return Promise.all([
			callServiceList('quectel-mhi'),
			callInterfaceStatus('cellular')
		]);
	},

	render: function(data) {
		const instances = data[0]?.['quectel-mhi']?.instances || {};
		const instance = instances[Object.keys(instances)[0]];
		const net = data[1] || {};
		const state = instance?.running ? _('running') : _('not running');
		const link = net.up ? _('up') : _('down');
		const address = net['ipv4-address']?.[0]?.address || _('no IPv4 address');

		const m = new form.Map('quectel-mhi', _('Quectel MHI'),
			_('Service: %s. Cellular interface: %s (%s). Saving changes automatically reloads the connection manager.')
				.format(state, link, address));
		const s = m.section(form.NamedSection, 'main', 'mhi', _('Connection settings'));

		let o = s.option(form.Value, 'apn', _('APN'));
		o.rmempty = false;
		o.placeholder = 'id';
		o.description = _('The mobile-data access point name. iD Mobile UK uses “id”.');

		return m.render();
	}
});
