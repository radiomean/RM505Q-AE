MHI Cellular LuCI integration for BPI-R4 / RM505Q-AE

This bundle assumes the custom pcie_mhi driver and its 180-second delayed
loader are already installed and working.

It installs:
  - /usr/bin/quectel-CM, built for OpenWrt aarch64/musl
  - a procd service that waits for the MHI QMI/network devices
  - the OpenWrt interface named "cellular" using rmnet_mhi0.1
  - an isolated firewall zone with LAN-to-cellular forwarding and NAT

The iD Mobile APN is preconfigured as "id". Ethernet WAN remains preferred:
cellular uses route metric 30.

Installation on the router:
  cd /tmp
  tar -xzf mhi-cellular-openwrt.tar.gz
  cd mhi-cellular-openwrt
  ./install.sh
  reboot

After boot, allow the existing 180-second MHI driver delay plus about one
minute for the cellular service to establish the QMI data call. Then open
LuCI: Network > Interfaces > Cellular.

To change APN later, edit the "quectel-mhi" configuration in LuCI under
System > Startup is not supported directly; use:
  uci set quectel-mhi.main.apn='your-apn'
  uci commit quectel-mhi
  /etc/init.d/quectel-mhi restart
