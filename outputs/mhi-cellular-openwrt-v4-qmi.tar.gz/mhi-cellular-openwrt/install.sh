#!/bin/sh
set -eu

base_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

cp "$base_dir/files/usr/bin/quectel-CM" /usr/bin/quectel-CM
cp "$base_dir/files/usr/bin/mhi-at" /usr/bin/mhi-at
cp "$base_dir/files/usr/libexec/quectel-mhi-dial" /usr/libexec/quectel-mhi-dial
cp "$base_dir/files/etc/init.d/quectel-mhi" /etc/init.d/quectel-mhi
if [ ! -f /etc/config/quectel-mhi ]; then
	cp "$base_dir/files/etc/config/quectel-mhi" /etc/config/quectel-mhi
fi
mkdir -p /www/luci-static/resources/view/quectel-mhi /usr/share/luci/menu.d /usr/share/rpcd/acl.d
cp "$base_dir/files/www/luci-static/resources/view/quectel-mhi/config.js" /www/luci-static/resources/view/quectel-mhi/config.js
cp "$base_dir/files/usr/share/luci/menu.d/luci-app-quectel-mhi.json" /usr/share/luci/menu.d/luci-app-quectel-mhi.json
cp "$base_dir/files/usr/share/rpcd/acl.d/luci-app-quectel-mhi.json" /usr/share/rpcd/acl.d/luci-app-quectel-mhi.json
chmod 755 /usr/bin/quectel-CM /usr/bin/mhi-at /usr/libexec/quectel-mhi-dial /etc/init.d/quectel-mhi
chmod 644 /etc/config/quectel-mhi

# A separate DHCP interface: cellular is backup to the existing Ethernet WAN.
uci -q delete network.cellular || true
uci set network.cellular='interface'
uci set network.cellular.proto='dhcp'
uci set network.cellular.device='rmnet_mhi0.1'
uci set network.cellular.metric='30'
uci set network.cellular.peerdns='1'
uci commit network

# Give LAN clients NATed access through cellular whenever it becomes active.
uci -q delete firewall.cellular || true
uci set firewall.cellular='zone'
uci set firewall.cellular.name='cellular'
uci add_list firewall.cellular.network='cellular'
uci set firewall.cellular.input='REJECT'
uci set firewall.cellular.output='ACCEPT'
uci set firewall.cellular.forward='REJECT'
uci set firewall.cellular.masq='1'
uci set firewall.cellular.mtu_fix='1'
uci -q delete firewall.lan_to_cellular || true
uci set firewall.lan_to_cellular='forwarding'
uci set firewall.lan_to_cellular.src='lan'
uci set firewall.lan_to_cellular.dest='cellular'
uci commit firewall

/etc/init.d/quectel-mhi enable
/etc/init.d/firewall reload
/etc/init.d/network reload
sync

echo 'Installed. Reboot once; after the existing 180-second MHI delay, Cellular will appear in LuCI under Network > Interfaces.'
