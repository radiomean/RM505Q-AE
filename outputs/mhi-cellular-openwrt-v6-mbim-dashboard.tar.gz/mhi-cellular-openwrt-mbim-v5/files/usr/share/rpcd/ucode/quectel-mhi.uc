#!/usr/bin/env ucode
'use strict';

import { popen, access } from 'fs';

function query(command) {
	let proc = popen(`/usr/bin/mhi-query /dev/mhi_DUN '${command}' 2>/dev/null`, 'r');

	if (!proc)
		return null;

	let output = proc.read('all');
	let status = proc.close();

	if (status != 0 || !output)
		return null;

	return trim(output);
}

const methods = {
	status: {
		call: function() {
			return {
				available: access('/dev/mhi_DUN'),
				identity: query('ATI'),
				sim: query('AT+CPIN?'),
				registration: query('AT+CEREG?'),
				network: query('AT+QNWINFO'),
				signal: query('AT+QCSQ'),
				serving_cell: query('AT+QENG="servingcell"'),
				carrier_aggregation: query('AT+QCAINFO'),
				pdp_contexts: query('AT+CGDCONT?'),
				pdp_activity: query('AT+CGACT?'),
				band_configuration: query('AT+QCFG="band"'),
				network_scan_mode: query('AT+QCFG="nwscanmode"'),
				pcie_mode: query('AT+QCFG="pcie/mode"'),
				pcie_mbim: query('AT+QCFG="pcie_mbim"'),
				mbn_profiles: query('AT+QMBNCFG="list"')
			};
		}
	}
};

return { 'luci.quectel-mhi': methods };
