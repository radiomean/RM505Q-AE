'use strict';
'require view';
'require form';
'require rpc';

const callServiceList = rpc.declare({
	object: 'service',
	method: 'list',
	params: [ 'name' ],
	expect: { '': {} }
});

const callInterfaceStatus = rpc.declare({
	object: 'network.interface',
	method: 'status',
	params: [ 'interface' ],
	expect: { '': {} }
});

const callModemStatus = rpc.declare({
	object: 'luci.quectel-mhi',
	method: 'status',
	expect: { '': {} }
});

const modemFields = [
	[ 'identity', _('Modem identity') ],
	[ 'sim', _('SIM status') ],
	[ 'registration', _('Registration') ],
	[ 'network', _('Network') ],
	[ 'signal', _('Signal (RSSI / RSRP / RSRQ / SINR)') ],
	[ 'serving_cell', _('Serving cell / tower / band') ],
	[ 'carrier_aggregation', _('Carrier aggregation') ],
	[ 'pdp_contexts', _('PDP contexts') ],
	[ 'pdp_activity', _('PDP activity') ],
	[ 'band_configuration', _('Configured bands') ],
	[ 'network_scan_mode', _('Network scan mode') ],
	[ 'pcie_mode', _('PCIe mode') ],
	[ 'pcie_mbim', _('PCIe MBIM mode') ],
	[ 'mbn_profiles', _('Carrier profiles (MBN)') ]
];

function formatResponse(value) {
	return value ? String(value).replace(/\r?\n/g, '\n') : _('Not available');
}

return view.extend({
	load: function() {
		return Promise.all([
			callServiceList('quectel-mhi'),
			callInterfaceStatus('cellular'),
			callModemStatus()
		]);
	},

	render: function(data) {
		const instances = data[0]?.['quectel-mhi']?.instances || {};
		const instance = instances[Object.keys(instances)[0]];
		const net = data[1] || {};
		const modem = data[2] || {};
		const state = instance?.running ? _('running') : _('not running');
		const link = net.up ? _('up') : _('down');
		const address = net['ipv4-address']?.[0]?.address || _('no IPv4 address');

		const m = new form.Map('quectel-mhi', _('Quectel MHI'),
			_('Service: %s. Cellular interface: %s (%s). Saving changes automatically reloads the connection manager.')
				.format(state, link, address));
		const s = m.section(form.NamedSection, 'main', 'mhi', _('Connection settings'));

		let o = s.option(form.Value, 'apn', _('APN'));
		o.rmempty = false;
		o.placeholder = 'id';
		o.description = _('The mobile-data access point name. iD Mobile UK uses “id”.');

		return m.render().then(function(nodes) {
			const rows = modemFields.map(function(field) {
				return E('div', { 'class': 'cbi-value' }, [
					E('label', { 'class': 'cbi-value-title' }, [ field[1] ]),
					E('div', { 'class': 'cbi-value-field' }, [
						E('pre', { 'style': 'white-space: pre-wrap; margin: 0' }, [ formatResponse(modem[field[0]]) ])
					])
				]);
			});

			const dashboard = E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, [ _('Live modem information') ]),
				E('p', { 'class': 'cbi-section-descr' }, [
					_('Read-only diagnostics obtained directly from the modem. Use Refresh to update signal, serving-cell, band, carrier-aggregation and registration information.')
				]),
				E('button', {
					'class': 'btn cbi-button cbi-button-action',
					'click': function(ev) { ev.preventDefault(); window.location.reload(); }
				}, [ _('Refresh') ]),
				E('div', { 'class': 'cbi-section-node' }, rows)
			]);

			dashboard.append(nodes);
			return dashboard;
		});
	}
});
