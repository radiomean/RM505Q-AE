'use strict';
'require view';
'require form';
'require rpc';

const callServiceList = rpc.declare({
	object: 'service',
	method: 'list',
	params: [ 'name' ],
	expect: { '': {} }
});

const callInterfaceStatus = rpc.declare({
	object: 'network.interface',
	method: 'status',
	params: [ 'interface' ],
	expect: { '': {} }
});

const callModemStatus = rpc.declare({
	object: 'luci.quectel-mhi',
	method: 'status',
	expect: { '': {} }
});

const modemFields = [
	[ 'identity', _('Modem identity') ],
	[ 'sim', _('SIM status') ],
	[ 'registration', _('Registration') ],
	[ 'network', _('Network') ],
	[ 'signal', _('Signal (RSSI / RSRP / RSRQ / SINR)') ],
	[ 'serving_cell', _('Serving cell / tower / band') ],
	[ 'carrier_aggregation', _('Carrier aggregation') ],
	[ 'pdp_contexts', _('PDP contexts') ],
	[ 'pdp_activity', _('PDP activity') ],
	[ 'mode_preference', _('Preferred radio mode') ],
	[ 'lte_band_preference', _('Allowed LTE bands') ],
	[ 'nr5g_band_preference', _('Allowed 5G SA bands') ],
	[ 'nsa_nr5g_band_preference', _('Allowed 5G NSA bands') ],
	[ 'nr5g_disable_mode', _('5G SA / NSA setting') ],
	[ 'network_scan_mode', _('Network scan mode') ],
	[ 'pcie_mode', _('PCIe mode') ],
	[ 'pcie_mbim', _('PCIe MBIM mode') ],
	[ 'mbn_profiles', _('Carrier profiles (MBN)') ]
];

function formatResponse(value) {
	return value ? String(value).replace(/\r?\n/g, '\n') : _('Not available');
}

function line(value) {
	return String(value || '').split(/\r?\n/).find(function(l) { return l && !/^(AT|OK|ERROR)/.test(l); }) || '';
}

function registration(value) {
	const m = line(value).match(/\+CEREG:\s*(?:\d+,)?(\d)/);
	const states = { 0: _('not registered'), 1: _('registered on home network'), 2: _('searching'), 3: _('registration denied'), 4: _('unknown'), 5: _('registered while roaming') };
	return m ? states[m[1]] || _('unknown') : _('not available');
}

function signal(value) {
	const m = line(value).match(/\+QCSQ:\s*"([^"]+)"\s*,\s*(-?\d+)\s*,\s*(-?\d+)/);
	if (!m)
		return _('not available');
	const rsrp = Number(m[3]);
	const quality = rsrp >= -85 ? _('excellent') : rsrp >= -95 ? _('good') : rsrp >= -105 ? _('fair') : _('weak');
	return '%s: RSSI %s dBm, RSRP %s dBm (%s)'.format(m[1], m[2], m[3], quality);
}

function currentNetwork(value) {
	const l = line(value);
	return l ? l.replace(/^\+QNWINFO:\s*/, '') : _('not available');
}

function mode(value) {
	const l = line(value).replace(/^\+QNWPREFCFG:\s*/, '');
	return l || _('not available');
}

function summaryRows(modem) {
	const entries = [
		[ _('Registration'), registration(modem.registration) ],
		[ _('Current network / band'), currentNetwork(modem.network) ],
		[ _('Signal quality'), signal(modem.signal) ],
		[ _('Radio preference'), mode(modem.mode_preference) ],
		[ _('Serving cell'), line(modem.serving_cell).replace(/^\+QENG:\s*/, '') || _('not available') ]
	];
	return entries.map(function(entry) {
		return E('div', { 'class': 'cbi-value' }, [
			E('label', { 'class': 'cbi-value-title' }, [ entry[0] ]),
			E('div', { 'class': 'cbi-value-field' }, [ entry[1] ])
		]);
	});
}

return view.extend({
	load: function() {
		return Promise.all([
			callServiceList('quectel-mhi'),
			callInterfaceStatus('cellular'),
			callModemStatus()
		]);
	},

	render: function(data) {
		const instances = data[0]?.['quectel-mhi']?.instances || {};
		const instance = instances[Object.keys(instances)[0]];
		const net = data[1] || {};
		const modem = data[2] || {};
		const state = instance?.running ? _('running') : _('not running');
		const link = net.up ? _('up') : _('down');
		const address = net['ipv4-address']?.[0]?.address || _('no IPv4 address');

		const m = new form.Map('quectel-mhi', _('Quectel MHI'),
			_('Service: %s. Cellular interface: %s (%s). Saving changes automatically reloads the connection manager.')
				.format(state, link, address));
		const s = m.section(form.NamedSection, 'main', 'mhi', _('Connection settings'));

		let o = s.option(form.Value, 'apn', _('APN'));
		o.rmempty = false;
		o.placeholder = 'id';
		o.description = _('The mobile-data access point name. iD Mobile UK uses “id”.');

		return m.render().then(function(nodes) {
			const rows = modemFields.map(function(field) {
				return E('div', { 'class': 'cbi-value' }, [
					E('label', { 'class': 'cbi-value-title' }, [ field[1] ]),
					E('div', { 'class': 'cbi-value-field' }, [
						E('pre', { 'style': 'white-space: pre-wrap; margin: 0' }, [ formatResponse(modem[field[0]]) ])
					])
				]);
			});

			const dashboard = E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, [ _('At-a-glance modem status') ]),
				E('p', { 'class': 'cbi-section-descr' }, [
					_('A readable interpretation of the modem’s current registration, network, signal and serving cell. The exact raw replies remain below for troubleshooting.')
				]),
				E('button', {
					'class': 'btn cbi-button cbi-button-action',
					'click': function(ev) { ev.preventDefault(); window.location.reload(); }
				}, [ _('Refresh') ]),
				E('div', { 'class': 'cbi-section-node' }, summaryRows(modem)),
				E('details', { 'style': 'margin-top: 1.5em' }, [
					E('summary', {}, [ _('Raw modem diagnostics') ]),
					E('div', { 'class': 'cbi-section-node' }, rows)
				])
			]);

			dashboard.append(nodes);
			return dashboard;
		});
	}
});
