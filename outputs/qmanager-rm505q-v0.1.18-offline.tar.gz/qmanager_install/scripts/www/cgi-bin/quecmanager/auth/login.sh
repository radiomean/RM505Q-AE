#!/bin/sh
# login.sh — Login and first-time password setup endpoint.
# POST {"password":"..."} for login
# POST {"password":"...","confirm":"...","enforce_strong":true|false} for first-time setup
#
# On success, sets HttpOnly session cookie + indicator cookie.
_SKIP_AUTH=1
. /usr/lib/qmanager/cgi_base.sh

qlog_init "cgi_auth_login"

# CORS preflight
if [ "$REQUEST_METHOD" = "OPTIONS" ]; then
    cgi_headers
    exit 0
fi

if [ "$REQUEST_METHOD" != "POST" ]; then
    cgi_headers
    cgi_method_not_allowed
fi

# Read POST body inline (to defer headers for 429 status)
if [ -n "$CONTENT_LENGTH" ] && [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
    POST_DATA=$(dd bs=1 count="$CONTENT_LENGTH" 2>/dev/null)
else
    cgi_headers
    cgi_error "no_body" "POST body is empty"
    exit 0
fi

_password=$(printf '%s' "$POST_DATA" | jq -r '.password // empty')
_confirm=$(printf '%s' "$POST_DATA" | jq -r '.confirm // empty')
_enforce_strong=$(printf '%s' "$POST_DATA" | jq -r 'if .enforce_strong == false then "false" else "true" end')

if [ -z "$_password" ]; then
    cgi_headers
    cgi_error "missing_password" "Password is required"
    exit 0
fi

# ---------------------------------------------------------------------------
# First-time setup mode
# ---------------------------------------------------------------------------
if is_setup_required; then
    if [ -z "$_confirm" ]; then
        cgi_headers
        jq -n '{"success":false,"error":"setup_required","setup_required":true}'
        exit 0
    fi

    # Min length 6 always; enforce_strong (absent = true) adds upper + lower + digit.
    _pw_len=$(printf '%s' "$_password" | wc -c)
    if [ "$_pw_len" -lt 6 ]; then
        cgi_headers
        cgi_error "password_weak" "Password must be at least 6 characters"
        exit 0
    fi
    if [ "$_enforce_strong" != "false" ] && ! qm_password_is_strong "$_password"; then
        cgi_headers
        cgi_error "password_weak" "Password must include uppercase, lowercase, and a number"
        exit 0
    fi

    if [ "$_password" != "$_confirm" ]; then
        cgi_headers
        cgi_error "password_mismatch" "Passwords do not match"
        exit 0
    fi

    if ! qm_save_password "$_password"; then
        qlog_error "First-time setup failed: could not write auth.json"
        cgi_headers
        cgi_error "save_failed" "Could not save the password"
        exit 0
    fi

    # Also set SSH root password. Non-fatal, but reported so the UI can warn
    # that SSH still has the install-time password.
    _ssh_synced=true
    if ! qm_set_ssh_password "$_password" 2>/dev/null; then
        _ssh_synced=false
        qlog_warn "SSH password sync failed"
    fi

    qlog_info "First-time password configured"

    _token=$(qm_create_session)
    qm_set_session_cookies "$_token"
    cgi_headers
    jq -n --argjson ssh "$_ssh_synced" '{"success":true,"ssh_synced":$ssh}'
    exit 0
fi

# ---------------------------------------------------------------------------
# Normal login
# ---------------------------------------------------------------------------
if ! qm_check_rate_limit; then
    echo "Status: 429 Too Many Requests"
    cgi_headers
    jq -n --argjson retry "$RATE_LIMIT_RETRY_AFTER" --argjson remaining "$RATE_LIMIT_ATTEMPTS_REMAINING" \
        '{"success":false,"error":"rate_limited","detail":"Too many failed attempts","retry_after":$retry,"attempts_remaining":$remaining}'
    exit 0
fi

if ! qm_verify_password "$_password"; then
    qm_record_failed_attempt
    # Read-only re-check to report how many attempts remain after the failure
    # that just happened. Never mutates state (see qm_get_rate_limit_status).
    qm_get_rate_limit_status
    qlog_warn "Failed login attempt"
    cgi_headers
    jq -n --argjson remaining "$RATE_LIMIT_ATTEMPTS_REMAINING" \
        '{"success":false,"error":"invalid_password","detail":"Invalid password","attempts_remaining":$remaining}'
    exit 0
fi

# Success
qm_clear_attempts
qm_cleanup_sessions
_token=$(qm_create_session)
qlog_info "Successful login"

qm_set_session_cookies "$_token"
cgi_headers
jq -n '{"success":true}'
