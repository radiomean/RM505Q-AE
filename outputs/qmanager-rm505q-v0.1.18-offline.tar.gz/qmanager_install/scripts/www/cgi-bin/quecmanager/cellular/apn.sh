#!/bin/sh
. /usr/lib/qmanager/cgi_base.sh
. /usr/lib/qmanager/cgi_at.sh
. /usr/lib/qmanager/platform.sh
. /usr/lib/qmanager/ttl_state.sh
# Events (for apn_apply.sh's append_event calls) — apn.sh did not previously
# source events.sh at all; same two-line pattern profiles/deactivate.sh
# already uses from a www-data-run CGI, not a new capability.
EVENTS_FILE="/tmp/qmanager_events.json"
MAX_EVENTS=300
. /usr/lib/qmanager/events.sh 2>/dev/null || {
    append_event() { :; }
}
# Synchronous CGI ceiling: a human is waiting on this HTTP response, so this
# endpoint cannot afford apn_apply.sh's 30s unattended-worker lock-wait
# default (qmanager_profile_apply keeps that default — nothing is blocked on
# it, so it should win the retry). Must be set BEFORE sourcing apn_apply.sh:
# its APN_APPLY_LOCK_WAIT default-assignment only evaluates once, on first
# source. Covers every apn_apply_write call site in this script (deactivate,
# WS6 save, legacy save).
APN_APPLY_LOCK_WAIT=5
. /usr/lib/qmanager/apn_apply.sh
. /usr/lib/qmanager/connection_validate.sh
. /usr/lib/qmanager/connection_store.sh
# =============================================================================
# apn.sh — CGI Endpoint: WAN Profile Management (GET + POST), AT-only
# =============================================================================
# RM520N-GL has no Casa RDB key-value store and no wmmd daemon, so every
# profile field is sourced directly from AT commands through qcmd.
#
# GET  -> List all 6 WAN profile slots (one per PDP context CID 1-6).
# POST -> {"action":"save"|"toggle"|"deactivate", ...} applies a configuration
#         change. "deactivate" is the WS6 single-APN action — see addendum below.
#
# AT commands used (GET):
#   AT+CGDCONT?        -> defined PDP contexts (CID, PDP type, APN)
#   AT+CGACT?          -> per-context activation state
#   AT+QICSGP=<cid>    -> Quectel context config (auth type, username, password)
#   AT+CGCONTRDP=<cid> -> dynamic params of an ACTIVE context (IP, gw, DNS)
#
# AT commands used (POST):
#   AT+CGDCONT=<cid>,"<pdp>","<apn>"               -> define APN + PDP type
#   AT+QICSGP=<cid>,<ctx>,"<apn>","<u>","<p>",<a>  -> APN + auth (Quectel)
#   AT+CGACT=<0|1>,<cid>                           -> toggle context (action: toggle)
#   AT+COPS=2 / AT+COPS=0                          -> detach/re-attach (action: save)
#
# The write-first attach cycle (AT+CGDCONT -> AT+COPS=2 -> AT+COPS=0 ->
# AT+CGCONTRDP verify) is NOT inlined here — it's the shared
# /usr/lib/qmanager/apn_apply.sh primitive (apn_apply_write), also used by
# qmanager_profile_apply and profiles/deactivate.sh. See that file's header
# for the full return-code contract and why write-first (not detach-first).
#
# NOTE: AT+CGAUTH is NOT supported on RM520N-GL firmware (returns ERROR), so
# authentication is written via the Quectel-native AT+QICSGP, which also
# carries the APN and an IP-stack context type. AT+QICSGP is written by this
# CGI directly (never by the shared primitive, which has no concept of auth).
#
# Endpoint: GET/POST /cgi-bin/quecmanager/cellular/apn.sh
# Install location: <docroot>/cgi-bin/quecmanager/cellular/apn.sh
#
# -----------------------------------------------------------------------------
# WS6 addendum — single-APN (RM551E `use-apn-settings.ts`) contract
# -----------------------------------------------------------------------------
# Additively, GET also emits `active`, `active_cid`, `internet_cid`, the
# single stored `apn{apn,pdp_type,cid}` object, and `cids[]` (one tagged entry
# per CID 1-$MAX_PROFILES) — all derived from the SAME AT reads above plus one
# extra AT+CGPADDR;+QMAP="WWAN" round-trip via cgi_at.sh's detect_active_cid().
# None of the existing 6-slot `profiles[]`/`toggle` output is touched.
#
# The single stored APN setting lives in its own flat sidecar,
# /etc/qmanager/apn_setting.json (sibling of apn_names.json, same www-data-
# owned dir, same atomic tmp+mv write pattern) — NOT the source's v2
# apn_profiles.json store, which has no migration primitive on this platform.
#
# POST action=save gets a NEW branch, selected when the request body has no
# `index` key (the legacy 6-slot contract always sends one; the WS6 contract
# sends `cid` instead). That branch runs a LIGHTER apply — just the shared
# apn_apply_write bracket -- deliberately skipping the AT+QICSGP auth write
# and the name-sidecar write below, so a single-APN save never blanks a
# legacy slot's stored auth credentials or profile name.
#
# POST action=deactivate is NEW: reverts the modem to carrier-default (blank
# CGDCONT APN) via the same COPS cycle and sets the sidecar's active=0. A
# request while already active=0 is a no-op that never touches the modem.
# -----------------------------------------------------------------------------

# --- Logging -----------------------------------------------------------------
qlog_init "cgi_apn"
cgi_headers
cgi_handle_options

# --- Fail closed if the shared attach-cycle primitive failed to load --------
# Every APN mutation on this endpoint (deactivate, WS6 save, legacy save) now
# goes through apn_apply_write. A defensive silent-skip here would let a
# broken install write AT+CGDCONT with NO bracket at all — reintroducing the
# exact bug this change fixes. Hard-stop instead of guessing.
if ! command -v apn_apply_write >/dev/null 2>&1; then
    qlog_error "apn_apply.sh library missing or failed to load"
    cgi_error "internal_error" "apn_apply.sh library missing or failed to load"
    exit 0
fi

# --- Configuration -----------------------------------------------------------
MAX_PROFILES=6
# Both sidecars live in /etc/qmanager, NOT /usrdata/qmanager. /etc/qmanager is
# owned www-data:www-data by install_backend(), which is what lets this CGI
# create its atomic temp file there. /usrdata/qmanager is deliberately pinned
# 0755 root:root (the root-run console service executes from a subdirectory of
# it), and creating a file needs write permission on the PARENT — so every
# write here silently no-opped for as long as the sidecars lived there.
# install_rm520n.sh's migrate_apn_sidecars() moves fielded devices across.
# /etc is persistent UBIFS on this platform, so this survives reboots and OTA.
NAME_FILE="$APN_NAMES_FILE"
# WS6 single-APN sidecar (see addendum above). Sibling of NAME_FILE, same dir,
# same lazy-create-on-first-save pattern — no installer seeding needed.
SETTING_FILE="$APN_SETTING_FILE"

# =============================================================================
# Helpers
# =============================================================================

# die <error_code> <detail> — emit a JSON error and stop. CGI exits 0; the
# client distinguishes success via the "success" field, not the HTTP status.
die() {
    qlog_error "$1: ${2:-}"
    cgi_error "$1" "${2:-}"
    exit 0
}

# Auth type <-> frontend vocabulary. AT (QICSGP/CGAUTH) uses 0/1/2.
auth_to_frontend() {
    case "$1" in
        1) echo "pap" ;;
        2) echo "chap" ;;
        *) echo "none" ;;
    esac
}
auth_to_at() {
    case "$1" in
        pap)  echo "1" ;;
        chap) echo "2" ;;
        *)    echo "0" ;;
    esac
}

# PDP type -> AT+QICSGP context type (1 = IPv4, 2 = IPv6, 3 = IPv4v6).
pdp_to_ctxtype() {
    case "$1" in
        ipv4) echo "1" ;;
        ipv6) echo "2" ;;
        *)    echo "3" ;;
    esac
}

# Carrier-provisioned APN classification. CIDs 2/3 ship as the operator's IMS
# (VoLTE) and SOS (emergency) contexts; tagging apn_type lets the frontend's
# isCarrierProfile() guard lock those rows so they cannot be edited or toggled.
apn_type_of() {
    case "$1" in
        ims|IMS) echo "ims" ;;
        sos|SOS) echo "emergency" ;;
        *)       echo "" ;;
    esac
}

# get_cgact_state <cid> — activation state for one CID from the cached
# AT+CGACT? response ("1" = active, "" otherwise).
get_cgact_state() {
    printf '%s\n' "$cgact_raw" | awk -F'[:,]' -v c="$1" '
        /\+CGACT:/ {
            cid = $2; gsub(/[^0-9]/, "", cid)
            if (cid == c) { st = $3; gsub(/[^0-9]/, "", st); print st; exit }
        }'
}

# parse_qicsgp <stripped_qicsgp_response> -> "<auth>\t<username>\t<haspw>"
# Hardware-verified field order (RM520N-GL):
#   +QICSGP: <ctxtype>,"<apn>","<username>","<password>",<authtype>
parse_qicsgp() {
    printf '%s\n' "$1" | awk -F'"' '
        /\+QICSGP:/ {
            user = $4
            pw   = $6
            auth = $7; gsub(/[^0-9]/, "", auth)
            haspw = (pw == "") ? "0" : "1"
            printf "%s\t%s\t%s\n", auth, user, haspw
            exit
        }'
}

# parse_cgcontrdp is now defined in cgi_at.sh (promoted verbatim from here —
# same 5-tab-field output, same callers/cut -f1..5 usage below). Kept sourced
# via the `. /usr/lib/qmanager/cgi_at.sh` line at the top of this file.

# =============================================================================
# GET — list all 6 WAN profile slots
# =============================================================================
if [ "$REQUEST_METHOD" = "GET" ]; then
    qlog_info "Listing WAN profiles (AT)"

    cgdcont_raw=$(run_at 'AT+CGDCONT?')
    cgact_raw=$(run_at 'AT+CGACT?')
    names_json=$(apn_names_read)

    tsv=""
    cid=1
    while [ "$cid" -le "$MAX_PROFILES" ]; do
        # --- AT+CGDCONT? — APN + PDP type for defined contexts -------------
        cgd_line=$(printf '%s\n' "$cgdcont_raw" | grep "^+CGDCONT: $cid,")
        if [ -n "$cgd_line" ]; then
            pdp_raw=$(printf '%s' "$cgd_line" | awk -F'"' '{print $2}')
            apn=$(printf '%s' "$cgd_line" | awk -F'"' '{print $4}')
            defined=1
        else
            pdp_raw=""
            apn=""
            defined=0
        fi
        pdp_type=$(pdp_to_frontend "$pdp_raw")
        apn_type=$(apn_type_of "$apn")

        # --- AT+CGACT? — activation state ----------------------------------
        state=$(get_cgact_state "$cid")
        [ "$state" = "1" ] && enabled=1 || enabled=0

        # --- AT+QICSGP — auth type, username, password presence ------------
        auth_type="none"
        username=""
        has_password=0
        if [ "$defined" = "1" ]; then
            qicsgp=$(run_at "AT+QICSGP=$cid")
            if [ -n "$qicsgp" ]; then
                qfields=$(parse_qicsgp "$qicsgp")
                qauth=$(printf '%s' "$qfields" | cut -f1)
                username=$(printf '%s' "$qfields" | cut -f2)
                has_password=$(printf '%s' "$qfields" | cut -f3)
                auth_type=$(auth_to_frontend "$qauth")
                [ -z "$has_password" ] && has_password=0
            fi
        fi

        # --- AT+CGCONTRDP — dynamic params of an ACTIVE context ------------
        # An inactive (or undefined) context returns a bare "OK" with no
        # +CGCONTRDP: line on RM520N-GL, so empty output simply means "no
        # runtime data" — it is not treated as a failure.
        v4addr=""; v4gw=""; dns1=""; dns2=""; v6addr=""
        if [ "$defined" = "1" ] && [ "$enabled" = "1" ]; then
            rdp=$(run_at "AT+CGCONTRDP=$cid")
            if [ -n "$rdp" ]; then
                rfields=$(parse_cgcontrdp "$rdp")
                v4addr=$(printf '%s' "$rfields" | cut -f1)
                v4gw=$(printf '%s'   "$rfields" | cut -f2)
                dns1=$(printf '%s'   "$rfields" | cut -f3)
                dns2=$(printf '%s'   "$rfields" | cut -f4)
                v6addr=$(printf '%s' "$rfields" | cut -f5)
            fi
        fi

        # --- Derived status fields -----------------------------------------
        [ -n "$v4addr" ] && status_ipv4="up" || status_ipv4=""
        [ -n "$v6addr" ] && status_ipv6="up" || status_ipv6=""
        if [ -n "$v4addr" ] || [ -n "$v6addr" ]; then
            connect_progress="connected"
        elif [ "$enabled" = "1" ]; then
            connect_progress="connecting"
        else
            connect_progress="disconnected"
        fi

        # 16 tab-separated columns; name is looked up from $names by index
        # in jq so user-typed text never enters the TSV stream.
        tsv="${tsv}${cid}	${apn}	${pdp_type}	${auth_type}	${username}	${has_password}	${enabled}	${cid}	${apn_type}	${status_ipv4}	${status_ipv6}	${connect_progress}	${v4addr}	${v4gw}	${dns1}	${dns2}
"
        cid=$((cid + 1))
    done

    profiles_json=$(printf '%s' "$tsv" | jq -Rsc --argjson names "$names_json" '
        split("\n") | map(select(length > 0) | split("\t") | {
            index:            (.[0] | tonumber),
            name:             ($names[.[0]] // ""),
            apn:              .[1],
            pdp_type:         .[2],
            auth_type:        .[3],
            username:         .[4],
            has_password:     (.[5] == "1"),
            mtu:              null,
            enabled:          (.[6] == "1"),
            default_route:    false,
            ip_passthrough:   false,
            modem_profile:    (.[7] | tonumber),
            apn_type:         .[8],
            vlan_index:       "",
            status_ipv4:      .[9],
            status_ipv6:      .[10],
            connect_progress: .[11],
            ipv4_address:     .[12],
            ipv4_gateway:     .[13],
            dns1:             .[14],
            dns2:             .[15],
            ipv6_address:     "",
            mtu_negotiated:   null,
            interface:        "",
            pdp_error:        ""
        })')

    if [ -z "$profiles_json" ]; then
        die "parse_failed" "Could not assemble WAN profile list"
    fi

    qlog_info "WAN profiles: $(printf '%s' "$profiles_json" | jq -c length) slots"

    # -------------------------------------------------------------------
    # WS6 addendum — active CID + tagged cids[] + stored single-APN object
    # -------------------------------------------------------------------
    # detect_active_cid (cgi_at.sh) issues one extra compound round-trip
    # (AT+CGPADDR;+QMAP="WWAN"); QMAP is authoritative, CGPADDR is the
    # fallback, and it defaults active_cid="1" on a transient read failure —
    # matching this endpoint's existing lenient GET behavior (the profiles[]
    # loop above already degrades to empty slots rather than dying on an AT
    # hiccup, so active_cid does the same instead of failing the whole GET).
    detect_active_cid
    internet_cid="$active_cid"

    # cids[] is derived from profiles_json (no extra AT calls) — index/apn/
    # apn_type are already known per CID from the AT+CGDCONT? loop above.
    cids_json=$(printf '%s' "$profiles_json" | jq -c --argjson active_cid "$active_cid" '
        [.[] | {
            cid:         .modem_profile,
            apn:         .apn,
            apn_type:    .apn_type,
            is_internet: (.modem_profile == $active_cid)
        }]')
    [ -z "$cids_json" ] && die "parse_failed" "Could not assemble modem context list"

    # Stored single-APN setting (WS6 sidecar). Defensive defaults mirror
    # apn_setting_read's {"active":0} fallback for a missing/corrupt file.
    setting_json=$(apn_setting_read)
    active_ptr=$(printf '%s' "$setting_json" | jq -r 'if .active == 1 then 1 else 0 end')
    setting_apn=$(printf '%s' "$setting_json" | jq -r 'if .apn == null then "" else .apn end')
    setting_pdp=$(printf '%s' "$setting_json" | jq -r 'if .pdp_type == null then "ipv4v6" else .pdp_type end')
    setting_cid=$(printf '%s' "$setting_json" | jq -r 'if .cid == null then 1 else .cid end')
    case "$setting_cid" in
        ''|*[!0-9]*) setting_cid=1 ;;
    esac

    apn_obj=$(jq -n \
        --arg apn "$setting_apn" \
        --arg pdp_type "$setting_pdp" \
        --argjson cid "$setting_cid" \
        '{apn: $apn, pdp_type: $pdp_type, cid: $cid}')
    [ -z "$apn_obj" ] && die "parse_failed" "Could not assemble stored APN object"

    qlog_info "APN setting (WS6): active=$active_ptr active_cid=$active_cid apn=$setting_apn"

    jq -n \
        --argjson profiles "$profiles_json" \
        --argjson max "$MAX_PROFILES" \
        --argjson active "$active_ptr" \
        --argjson active_cid "$active_cid" \
        --argjson internet_cid "$internet_cid" \
        --argjson apn_obj "$apn_obj" \
        --argjson cids "$cids_json" \
        '{
            success: true,
            max_profiles: $max,
            data_source: "at",
            profiles: $profiles,
            active: $active,
            active_cid: $active_cid,
            internet_cid: $internet_cid,
            apn: $apn_obj,
            cids: $cids
        }'
    exit 0
fi

# =============================================================================
# POST — apply a profile change ({"action":"save"|"toggle", ...})
# =============================================================================
if [ "$REQUEST_METHOD" = "POST" ]; then

    cgi_read_post
    ACTION=$(printf '%s' "$POST_DATA" | jq -r '.action // empty')

    # -----------------------------------------------------------------------
    # action: deactivate — WS6 single-APN contract, NEW. No client-supplied
    # cid/index (the target CID is read from the sidecar) so this must run
    # BEFORE the common index/cid validation below.
    # -----------------------------------------------------------------------
    if [ "$ACTION" = "deactivate" ]; then
        # Shared with the config-backup applier (connection_store.sh).
        apn_setting_deactivate || die "$APN_ERR_CODE" "$APN_ERR_DETAIL"
        if [ "$APN_SAVE_PERSISTED" != "1" ]; then
            jq -n '{success: true, active: 0, persisted: false}'
            exit 0
        fi
        jq -n '{success: true, active: 0}'
        exit 0
    fi

    # --- Common: validate the target slot index (1-6 == CID) ---------------
    # action:"save" accepts either the legacy 6-slot `index` field or the
    # WS6 single-APN `cid` field (same integer, different key name depending
    # on which frontend contract is calling).
    IDX=$(printf '%s' "$POST_DATA" | jq -r '(.index // .cid // empty) | tostring')
    conn_validate_cid "$IDX" "$MAX_PROFILES" || die "$CONN_ERR_CODE" "$CONN_ERR_DETAIL"

    # -----------------------------------------------------------------------
    # action: toggle — activate/deactivate one PDP context
    # -----------------------------------------------------------------------
    if [ "$ACTION" = "toggle" ]; then
        ENABLED=$(printf '%s' "$POST_DATA" | jq -r 'if .enabled == true then "1" elif .enabled == false then "0" else "" end')
        [ -z "$ENABLED" ] && die "missing_fields" "enabled (boolean) is required"

        qlog_info "Toggle profile $IDX -> enabled=$ENABLED"
        if ! run_at "AT+CGACT=$ENABLED,$IDX" >/dev/null; then
            die "cgact_failed" "AT+CGACT=$ENABLED,$IDX failed"
        fi
        cgi_success
        exit 0
    fi

    # -----------------------------------------------------------------------
    # action: save — write APN, PDP type, auth, name; then reactivate
    # -----------------------------------------------------------------------
    if [ "$ACTION" = "save" ]; then
        # ---------------------------------------------------------------
        # WS6 single-APN save (use-apn-settings.ts ApnSaveRequest contract:
        # {action:"save", apn, pdp_type, cid} — no "index"). Selected purely
        # by the ABSENCE of "index" in the request body, so the legacy
        # 6-slot save path below is completely untouched for callers that
        # send one.
        #
        # This is deliberately a LIGHTER apply than the legacy save below:
        # just the shared apn_apply_write bracket (AT+CGDCONT -> AT+COPS=2 ->
        # AT+COPS=0 -> verify), no AT+QICSGP auth write and no name-sidecar
        # write — a single-APN save must never blank out a legacy slot's
        # stored auth credentials or profile name just because the WS6
        # request didn't carry them.
        # ---------------------------------------------------------------
        HAS_INDEX=$(printf '%s' "$POST_DATA" | jq -r 'has("index")')
        if [ "$HAS_INDEX" != "true" ]; then
            WS_APN=$(printf '%s' "$POST_DATA" | jq -r 'if .apn == null then "" else .apn end')
            WS_PDP=$(printf '%s' "$POST_DATA" | jq -r 'if .pdp_type == null then "" else .pdp_type end')

            conn_validate_apn_setting "$WS_APN" "$WS_PDP" || die "$CONN_ERR_CODE" "$CONN_ERR_DETAIL"
            WS_PDP_AT=$(pdp_to_at "$WS_PDP")

            qlog_info "Save APN (WS6): apn=$WS_APN pdp=$WS_PDP_AT cid=$IDX"

            # Attach cycle, TTL/HL re-apply and sidecar write: shared with the
            # config-backup applier (connection_store.sh).
            apn_setting_apply "$IDX" "$WS_PDP" "$WS_APN" || die "$APN_ERR_CODE" "$APN_ERR_DETAIL"
            if [ "$APN_SAVE_PERSISTED" != "1" ]; then
                jq -n '{success: true, active: 1, persisted: false}'
                exit 0
            fi

            jq -n '{success: true, active: 1}'
            exit 0
        fi

        # ---- Legacy 6-slot save (unchanged) --------------------------------
        NAME=$(printf '%s' "$POST_DATA" | jq -r '.name // ""')
        APN=$(printf '%s' "$POST_DATA" | jq -r '.apn // ""')
        PDP=$(printf '%s' "$POST_DATA" | jq -r '.pdp_type // ""')
        AUTH=$(printf '%s' "$POST_DATA" | jq -r '.auth_type // "none"')
        USERNAME=$(printf '%s' "$POST_DATA" | jq -r '.username // ""')
        PASSWORD=$(printf '%s' "$POST_DATA" | jq -r '.password // ""')
        MTU=$(printf '%s' "$POST_DATA" | jq -r 'if (.mtu | type) == "number" then (.mtu | tostring) else "" end')

        # --- Validate ------------------------------------------------------
        [ -z "$APN" ] && die "missing_fields" "apn is required"
        PDP_AT=$(pdp_to_at "$PDP")
        [ -z "$PDP_AT" ] && die "invalid_pdp_type" "pdp_type must be ipv4, ipv6, or ipv4v6"

        # Reject embedded double-quotes: they would break the quoted AT args.
        case "$APN$USERNAME$PASSWORD" in
            *'"'*) die "invalid_value" "APN/username/password may not contain a double-quote" ;;
        esac

        AUTH_AT=$(auth_to_at "$AUTH")

        qlog_info "Save profile $IDX: apn=$APN pdp=$PDP_AT auth=$AUTH"

        # Apply order: write BOTH NVM fields first — auth (AT+QICSGP) THEN
        # APN (AT+CGDCONT, via the shared apn_apply.sh primitive) — then
        # detach -> re-attach -> verify. Both writes must land BEFORE the
        # bracket detaches: AT+QICSGP carries the username/password/auth-type
        # for the context, and the single re-attach that follows is what
        # actually presents an Attach Request to the MME/PGW. If QICSGP
        # landed AFTER the attach cycle instead, the modem would re-register
        # using the OLD stored credentials — the new auth would sit unused
        # in NVM until some later, unrelated re-registration picked it up.
        # That is the exact same failure shape ("looks applied, isn't") that
        # this whole change exists to fix, one layer down, so QICSGP must
        # sequence BEFORE the primitive call, not after it.
        #
        # Why a full attach cycle at all (not AT+CGACT=0,<cid> / AT+CGACT=1,
        # <cid>): in EPS (LTE / 5G-NSA), the default EPS bearer for CID 1 is
        # established at *attach time* and the APN is a contract field with
        # the MME/PGW. AT+CGACT only cycles the user-plane of an already-
        # established bearer — the MME keeps the original APN. Neither the
        # new CGDCONT value nor the new QICSGP auth reaches the network
        # without a fresh Attach Request, which is what the primitive's
        # AT+COPS=2 / AT+COPS=0 bracket forces — carrying BOTH NVM writes at
        # once, since they both precede it.
        #
        # The CGI runs on lighttpd via LAN/Wi-Fi to the modem; the cellular
        # WAN drops briefly during the cycle, but the HTTP/SSH path to the
        # modem itself does not.

        # --- Step 3 (moved ahead of the primitive): APN + PDP
        # authentication via AT+QICSGP -------------------------------------
        # AT+CGAUTH is unsupported on RM520N-GL, so the Quectel-native
        # AT+QICSGP carries the auth write. It also (re)sets the APN and an
        # IP-stack context type — harmless, since the APN matches what the
        # primitive is about to write via CGDCONT below. With no auth, the
        # username/password fields are written empty to clear any stored
        # credential. A blank password on a PAP/CHAP profile means "keep the
        # stored secret": QICSGP's password field is mandatory, so the
        # existing value is read back and reused rather than wiped. A
        # QICSGP failure here happens with the modem STILL ATTACHED (the
        # primitive's detach/attach bracket hasn't run yet) — a strict
        # improvement over the old inline bracket, where a QICSGP failure
        # happened mid-detach and needed a best-effort cops_recover() to
        # scramble the modem back onto the network. Here the failure path
        # simply returns with the device untouched and still registered.
        # Take the bracket lock BEFORE the QICSGP write, and hold it across
        # the apn_apply_write call below (see apn_apply.sh > LOCK LEASE).
        # QICSGP is a modem write that also sets the APN, so running it
        # outside the lock meant a subsequent apn_busy (rc=7) returned
        # "modem unchanged" AFTER the configured APN had already moved with
        # no attach cycle behind it — the exact configured/negotiated split
        # this endpoint's bracket exists to prevent. Leasing here means a
        # busy modem is reported before anything is written at all.
        # Every failure path below is `die`, which exits; the kernel drops
        # the flock when the process closes fd 8, so no leak.
        if ! apn_apply_lock; then
            die "apn_busy" "Another APN apply is already in progress; try again shortly"
        fi

        CTXTYPE=$(pdp_to_ctxtype "$PDP")
        if [ "$AUTH_AT" = "0" ]; then
            qicsgp_cmd="AT+QICSGP=$IDX,$CTXTYPE,\"$APN\",\"\",\"\",0"
        else
            eff_pass="$PASSWORD"
            if [ -z "$eff_pass" ]; then
                cur_qicsgp=$(run_at "AT+QICSGP=$IDX")
                eff_pass=$(printf '%s\n' "$cur_qicsgp" | awk -F'"' '/\+QICSGP:/ {print $6; exit}')
                qlog_info "Profile $IDX: password blank — preserving stored credential"
            fi
            qicsgp_cmd="AT+QICSGP=$IDX,$CTXTYPE,\"$APN\",\"$USERNAME\",\"$eff_pass\",$AUTH_AT"
        fi
        if ! run_at "$qicsgp_cmd" >/dev/null; then
            die "qicsgp_failed" "AT+QICSGP failed for CID $IDX"
        fi

        # --- Steps 1/2/6 (old): write-first attach cycle via the primitive -
        # QICSGP has already landed above, so this single bracket's
        # re-attach carries BOTH the new APN and the new auth.
        apn_apply_write "$IDX" "$PDP_AT" "$APN"
        # End the lease before dispatching on the result: every arm below is
        # `die`, and the sidecar/TTL work after it must not hold the modem
        # mutex. rc=7 is unreachable under a lease (apn_apply_lock already
        # reported busy above) but the arm is kept as a backstop.
        apn_apply_unlock
        case "$APN_APPLY_RC" in
            1) die "cgdcont_failed" "$APN_APPLY_DETAIL" ;;
            2) die "cops_detach_failed" "$APN_APPLY_DETAIL" ;;
            3) die "cops_attach_failed" "$APN_APPLY_DETAIL" ;;
            4) die "apn_mismatch" "$APN_APPLY_DETAIL" ;;
            5) die "cops_attach_failed" "$APN_APPLY_DETAIL" ;;
            7) die "apn_busy" "$APN_APPLY_DETAIL" ;;
            # 0 (done): fall through to name / MTU / TTL below.
        esac

        # --- Step 4: persist the profile name (filesystem only) -----------
        if ! apn_name_write "$IDX" "$NAME"; then
            qlog_warn "Failed to persist profile name for CID $IDX to $NAME_FILE"
        fi

        # --- Step 5: MTU — no reliable per-context AT write on RM520N -----
        # Do not report a write that cannot happen as success.
        if [ -n "$MTU" ] && [ "$MTU" != "1500" ] && [ "$MTU" != "0" ]; then
            qlog_warn "Profile $IDX: requested MTU=$MTU ignored (no per-context MTU write on RM520N-GL AT)"
        fi

        # --- Step 6 (old): re-attach — now handled inside apn_apply_write --

        # --- Step 7: re-apply persisted TTL/HL hotspot-bypass rules -------
        # iptables rules survive interface flaps, so this is belt-and-
        # suspenders, but it keeps parity with the documented "TTL is
        # re-applied after an APN change" behavior.
        read -r persisted_ttl persisted_hl <<EOF
$(ttl_state_read_persisted)
EOF
        persisted_ttl="${persisted_ttl:-0}"
        persisted_hl="${persisted_hl:-0}"
        if [ "$persisted_ttl" -gt 0 ] 2>/dev/null || [ "$persisted_hl" -gt 0 ] 2>/dev/null; then
            qlog_info "Re-applying persisted TTL=$persisted_ttl HL=$persisted_hl after profile save"
            if ! ttl_state_apply "$persisted_ttl" "$persisted_hl"; then
                qlog_warn "TTL/HL re-apply failed after profile save; rules may be partial"
            fi
        fi

        cgi_success
        exit 0
    fi

    die "invalid_action" "action must be 'save', 'toggle', or 'deactivate'"
fi

# --- Method not allowed -------------------------------------------------------
cgi_method_not_allowed
