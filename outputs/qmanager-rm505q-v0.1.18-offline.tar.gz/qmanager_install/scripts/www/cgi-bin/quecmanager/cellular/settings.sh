#!/bin/sh
. /usr/lib/qmanager/cgi_base.sh
# =============================================================================
# settings.sh — CGI Endpoint: Cellular Basic Settings (GET + POST)
# =============================================================================
# GET:  Reads current SIM slot, CFUN, mode_pref, nr5g_disable_mode, and AMBR
# POST: Applies settings changes (sim_slot, cfun, mode_pref, nr5g_mode)
#
# AT commands used (GET):
#   AT+QUIMSLOT?                        -> SIM slot (1 or 2)
#   AT+CFUN?                            -> Functionality mode (0, 1, 4)
#   AT+QNWPREFCFG="mode_pref"          -> Network mode (AUTO, LTE, NR5G, etc.)
#   AT+QNWPREFCFG="nr5g_disable_mode"  -> NR5G mode (0=both, 1=SA off, 2=NSA off)
#   AT+QNWPREFCFG="roam_pref"          -> Roaming preference (1, 3, 255)
#   AT+QNWCFG="lte_ambr"               -> LTE AMBR per APN
#   AT+QNWCFG="nr5g_ambr"              -> NR5G AMBR per DNN
#   AT+QSIMDET?                        -> SIM detect enable + insert level
#
# AT+QSIMCFG="dual_slot_status"        -> Dual-SIM slot/ICCID status (read-only)
#   Issued as its OWN independent qcmd call, deliberately NOT appended to the
#   compound read above. It's undocumented outside release notes for this
#   firmware family and may be rejected on an older/different build; qcmd
#   fails its ENTIRE compound buffer if any one sub-command errors, so
#   appending it there would blank out all six settings + AMBR on any
#   firmware that doesn't support it. Isolated here, its failure only omits
#   the `dual_slot` key from the response — everything else keeps working.
#
# AT commands used (POST):
#   AT+QUIMSLOT=<1|2>
#   AT+CFUN=<0|1|4>
#   AT+QNWPREFCFG="mode_pref",<value>
#   AT+QNWPREFCFG="nr5g_disable_mode",<0|1|2>
#   AT+QNWPREFCFG="roam_pref",<1|3|255>
#   AT+QSIMDET=<0|1>,<insert_level>    -> insert_level preserved from read, else 1
#
# Endpoint: GET/POST /cgi-bin/quecmanager/cellular/settings.sh
# Install location: /www/cgi-bin/quecmanager/cellular/settings.sh
# =============================================================================

# --- Logging -----------------------------------------------------------------
qlog_init "cgi_cellular_settings"
cgi_headers
cgi_handle_options

# --- SIM slot read-back verification (shared with qmanager_watchcat) ---------
. /usr/lib/qmanager/slot_verify.sh
. /usr/lib/qmanager/radio_validate.sh

# --- Configuration -----------------------------------------------------------
CMD_GAP=0.2

# --- NR5G AMBR unit code to Kbps multiplier ----------------------------------
nr5g_unit_to_kbps() {
    case "$1" in
        1) echo 1 ;; 2) echo 4 ;; 3) echo 16 ;; 4) echo 64 ;;
        5) echo 256 ;; 6) echo 1000 ;; 7) echo 4000 ;; 8) echo 16000 ;;
        9) echo 64000 ;; 10) echo 256000 ;; 11) echo 1000000 ;;
        12) echo 4000000 ;; 13) echo 16000000 ;; 14) echo 64000000 ;;
        15) echo 256000000 ;; *) echo 0 ;;
    esac
}

# =============================================================================
# GET — Fetch current settings and AMBR data
# =============================================================================
if [ "$REQUEST_METHOD" = "GET" ]; then
    qlog_info "Fetching cellular settings"

    # --- Compound AT: fetch all settings in one call ---
    # qcmd signals failure three ways at once: exit 1, "ERROR: <code>" on
    # stderr, and empty stdout. On success it always echoes the command line
    # back before the payload, so a genuine success can never produce empty
    # stdout — `rc` (captured on the very next statement, before anything
    # else touches $?) is the honest signal, not an `-z "$raw"` guess. Without
    # this, a lock-timeout or modem ERROR here fell through to the seeded
    # defaults below and reported success:true with fabricated settings.
    raw=$(qcmd 'AT+QUIMSLOT?;+CFUN?;+QNWPREFCFG="mode_pref";+QNWPREFCFG="nr5g_disable_mode";+QNWPREFCFG="roam_pref";+QNWCFG="lte_ambr";+QNWCFG="nr5g_ambr";+QSIMDET?' 2>/dev/null)
    rc=$?
    [ -z "$raw" ] && qlog_warn "Compound AT query returned empty response"

    if [ $rc -ne 0 ]; then
        qlog_error "Compound AT query failed (rc=$rc); refusing to fabricate settings"
        cgi_error "read_failed" "Unable to read cellular settings from modem"
        exit 0
    fi

    # --- SIM Slot ---
    sim_slot="1"
    val=$(printf '%s\n' "$raw" | grep '+QUIMSLOT:' | head -1 | sed 's/+QUIMSLOT: //' | tr -d ' \r')
    [ -n "$val" ] && sim_slot="$val"

    # --- CFUN ---
    cfun="1"
    val=$(printf '%s\n' "$raw" | grep '+CFUN:' | head -1 | sed 's/+CFUN: //' | tr -d ' \r')
    [ -n "$val" ] && cfun="$val"

    # --- Network Mode ---
    mode_pref="AUTO"
    val=$(printf '%s\n' "$raw" | grep '+QNWPREFCFG:.*"mode_pref"' | head -1 | sed 's/.*"mode_pref",//' | tr -d ' \r')
    [ -n "$val" ] && mode_pref="$val"

    # --- NR5G Mode ---
    nr5g_mode="0"
    val=$(printf '%s\n' "$raw" | grep '+QNWPREFCFG:.*"nr5g_disable_mode"' | head -1 | sed 's/.*"nr5g_disable_mode",//' | tr -d ' \r')
    [ -n "$val" ] && nr5g_mode="$val"

    # --- Roaming Preference ---
    roam_pref="255"
    val=$(printf '%s\n' "$raw" | grep '+QNWPREFCFG:.*"roam_pref"' | head -1 | sed 's/.*"roam_pref",//' | tr -d ' \r')
    [ -n "$val" ] && roam_pref="$val"

    # --- SIM Detect ---
    sim_detect="0"
    sim_detect_level="1"
    val=$(printf '%s\n' "$raw" | grep '+QSIMDET:' | head -1 | sed 's/+QSIMDET: //' | tr -d ' \r')
    if [ -n "$val" ]; then
        sim_detect=$(printf '%s' "$val" | cut -d',' -f1)
        lvl=$(printf '%s' "$val" | cut -d',' -f2)
        [ -n "$lvl" ] && sim_detect_level="$lvl"
    fi

    # --- LTE AMBR ---
    lte_ambr_json="[]"
    lte_ambr_lines=$(printf '%s\n' "$raw" | grep '+QNWCFG: "lte_ambr"')
    if [ -n "$lte_ambr_lines" ]; then
        lte_tmpfile="/tmp/qmanager_lte_ambr.tmp.$$"
        : > "$lte_tmpfile"
        printf '%s\n' "$lte_ambr_lines" | while IFS= read -r line; do
            csv=$(printf '%s' "$line" | sed 's/+QNWCFG: "lte_ambr",//g' | tr -d ' \r')
            apn=$(printf '%s' "$csv" | cut -d',' -f1 | tr -d '"')
            dl=$(printf '%s' "$csv" | cut -d',' -f2)
            ul=$(printf '%s' "$csv" | cut -d',' -f3)
            [ -n "$apn" ] && [ -n "$dl" ] && [ -n "$ul" ] && \
                printf '%s\t%s\t%s\n' "$apn" "$dl" "$ul" >> "$lte_tmpfile"
        done
        if [ -s "$lte_tmpfile" ]; then
            lte_ambr_json=$(jq -Rsc '
                split("\n") | map(select(length > 0) | split("\t") |
                    {apn: .[0], dl_kbps: (.[1] | tonumber), ul_kbps: (.[2] | tonumber)}
                )
            ' "$lte_tmpfile")
        fi
        rm -f "$lte_tmpfile"
    fi

    # --- NR5G AMBR ---
    nr5g_ambr_json="[]"
    nr5g_ambr_lines=$(printf '%s\n' "$raw" | grep '+QNWCFG: "nr5g_ambr"')
    if [ -n "$nr5g_ambr_lines" ]; then
        nr5g_tmpfile="/tmp/qmanager_nr5g_ambr.tmp.$$"
        : > "$nr5g_tmpfile"
        printf '%s\n' "$nr5g_ambr_lines" | while IFS= read -r line; do
            csv=$(printf '%s' "$line" | sed 's/+QNWCFG: "nr5g_ambr",//g' | tr -d ' \r')
            dnn=$(printf '%s' "$csv" | cut -d',' -f1 | tr -d '"')
            unit_dl=$(printf '%s' "$csv" | cut -d',' -f2)
            session_dl=$(printf '%s' "$csv" | cut -d',' -f3)
            unit_ul=$(printf '%s' "$csv" | cut -d',' -f4)
            session_ul=$(printf '%s' "$csv" | cut -d',' -f5)

            # Guard BEFORE arithmetic (mirrors the LTE branch above) — a
            # short/truncated +QNWCFG: "nr5g_ambr" line leaves session_dl or
            # session_ul empty, and `$((mult_dl * ))` is a shell syntax error
            # that prints straight to stdout inside this CGI's JSON body.
            if [ -n "$dnn" ] && [ -n "$session_dl" ] && [ -n "$session_ul" ]; then
                mult_dl=$(nr5g_unit_to_kbps "$unit_dl")
                mult_ul=$(nr5g_unit_to_kbps "$unit_ul")

                # awk, NOT $(( )). This script is #!/bin/sh = BusyBox ash, whose
                # arithmetic is 32-bit and wraps SILENTLY with no error:
                #   $ sh -c 'echo $((256000000 * 255))'  ->  855490560
                # (true value 65,280,000,000). The nr5g_unit_to_kbps table tops
                # out at 256000000 and `session_dl` is an unvalidated raw value
                # from the modem, so a large unit paired with a modest session
                # count silently corrupts the rate shown to the user rather than
                # failing loudly. awk uses doubles — exact for integers well
                # past the theoretical max product here.
                dl_kbps=$(awk -v m="$mult_dl" -v s="$session_dl" 'BEGIN{printf "%.0f", m*s}')
                ul_kbps=$(awk -v m="$mult_ul" -v s="$session_ul" 'BEGIN{printf "%.0f", m*s}')
                printf '%s\t%s\t%s\n' "$dnn" "$dl_kbps" "$ul_kbps" >> "$nr5g_tmpfile"
            fi
        done
        if [ -s "$nr5g_tmpfile" ]; then
            nr5g_ambr_json=$(jq -Rsc '
                split("\n") | map(select(length > 0) | split("\t") |
                    {dnn: .[0], dl_kbps: (.[1] | tonumber), ul_kbps: (.[2] | tonumber)}
                )
            ' "$nr5g_tmpfile")
        fi
        rm -f "$nr5g_tmpfile"
    fi

    # --- Dual SIM Slot Status (independent, isolated failure) ----------------
    # AT+QSIMCFG="dual_slot_status" is undocumented outside release notes for
    # this firmware family and may be rejected on older/different builds.
    # Issued as its own qcmd call (NOT appended to the compound read above)
    # so a rejection here only omits this one field from the response — it
    # can never blank out the six settings + AMBR that already work today.
    #
    # Wire shape (confirmed live): two 6-field groups, slot 1 then slot 2,
    # with NO slot-index token — slot number is purely positional. Only
    # index 2 (active_status, 1=selected/0=standby) and index 6 (ICCID) per
    # group are confirmed meaning; fields 1/3/5 are unconfirmed (one
    # candidate for field 3 collides with a different sub-command,
    # "sim_state") and are deliberately never surfaced in the JSON.
    dual_slot_json=""
    ds_raw=$(qcmd 'AT+QSIMCFG="dual_slot_status"' 2>/dev/null)
    ds_rc=$?
    if [ $ds_rc -eq 0 ] && [ -n "$ds_raw" ]; then
        ds_line=$(printf '%s\n' "$ds_raw" | grep '+QSIMCFG:.*"dual_slot_status"' | head -1 | sed 's/.*"dual_slot_status",//' | tr -d ' \r')
        ds_count=$(printf '%s' "$ds_line" | awk -F',' '{print NF}')
        if [ -n "$ds_line" ] && [ "$ds_count" = "12" ]; then
            s1_active=$(printf '%s' "$ds_line" | cut -d',' -f2)
            s1_iccid=$(printf '%s' "$ds_line" | cut -d',' -f6)
            s2_active=$(printf '%s' "$ds_line" | cut -d',' -f8)
            s2_iccid=$(printf '%s' "$ds_line" | cut -d',' -f12)
            if [ -n "$s1_active" ] && [ -n "$s1_iccid" ] && [ -n "$s2_active" ] && [ -n "$s2_iccid" ]; then
                dual_slot_json=$(jq -n \
                    --arg s1a "$s1_active" --arg s1i "$s1_iccid" \
                    --arg s2a "$s2_active" --arg s2i "$s2_iccid" \
                    '[
                        {slot: 1, active: ($s1a == "1"), iccid: $s1i},
                        {slot: 2, active: ($s2a == "1"), iccid: $s2i}
                    ]')
            fi
        fi
        if [ -z "$dual_slot_json" ]; then
            qlog_warn "dual_slot_status response did not parse as 12 comma-separated fields; omitting dual_slot"
        fi
    else
        qlog_warn "AT+QSIMCFG=\"dual_slot_status\" read failed (rc=$ds_rc) or empty; omitting dual_slot"
    fi
    dual_slot_arg="${dual_slot_json:-null}"

    # --- Build response ---
    qlog_info "Settings: slot=$sim_slot cfun=$cfun mode=$mode_pref nr5g=$nr5g_mode roam=$roam_pref sim_detect=$sim_detect"
    jq -n \
        --arg sim_slot "$sim_slot" \
        --arg cfun "$cfun" \
        --arg mode_pref "$mode_pref" \
        --arg nr5g_mode "$nr5g_mode" \
        --arg roam_pref "$roam_pref" \
        --arg sim_detect "$sim_detect" \
        --arg sim_detect_level "$sim_detect_level" \
        --argjson lte_ambr "$lte_ambr_json" \
        --argjson nr5g_ambr "$nr5g_ambr_json" \
        --argjson dual_slot "$dual_slot_arg" \
        '(if $dual_slot == null then {} else {dual_slot: $dual_slot} end) as $extra
        | {
            success: true,
            settings: {
                sim_slot: ($sim_slot | tonumber),
                cfun: ($cfun | tonumber),
                mode_pref: $mode_pref,
                nr5g_mode: ($nr5g_mode | tonumber),
                roam_pref: ($roam_pref | tonumber),
                sim_detect: ($sim_detect | tonumber),
                sim_detect_level: ($sim_detect_level | tonumber)
            },
            ambr: {
                lte: $lte_ambr,
                nr5g: $nr5g_ambr
            }
        } + $extra'
    exit 0
fi

# =============================================================================
# POST — Apply settings changes
# =============================================================================
if [ "$REQUEST_METHOD" = "POST" ]; then

    cgi_read_post

    # qcmd puts "ERROR: <code>" on STDERR and leaves stdout empty on failure
    # (exit 1 too) — it never writes "ERROR" into stdout. So the historic
    # `case "$result" in *ERROR*)` idiom used below at every write site was
    # matching against stdout and could NEVER take that arm: a rejected write
    # always fell through to the `*)` "success" branch. at_write is the fix —
    # it checks the actual exit status. No `local` in BusyBox ash, so the
    # working vars are `_aw_`-prefixed to avoid clobbering caller scope.
    at_write() {
        _aw_out=$(qcmd "$1" 2>/dev/null)
        _aw_rc=$?
        return $_aw_rc
    }

    # --- Extract fields (use "unset" sentinel for missing keys) ---
    SIM_SLOT=$(printf '%s' "$POST_DATA" | jq -r 'if has("sim_slot") then (.sim_slot | tostring) else "unset" end')
    CFUN=$(printf '%s' "$POST_DATA" | jq -r 'if has("cfun") then (.cfun | tostring) else "unset" end')
    MODE_PREF=$(printf '%s' "$POST_DATA" | jq -r 'if has("mode_pref") then .mode_pref else "unset" end')
    NR5G_MODE=$(printf '%s' "$POST_DATA" | jq -r 'if has("nr5g_mode") then (.nr5g_mode | tostring) else "unset" end')
    ROAM_PREF=$(printf '%s' "$POST_DATA" | jq -r 'if has("roam_pref") then (.roam_pref | tostring) else "unset" end')
    SIM_DETECT=$(printf '%s' "$POST_DATA" | jq -r 'if has("sim_detect") then (.sim_detect | tostring) else "unset" end')

    qlog_info "Apply settings: slot=$SIM_SLOT cfun=$CFUN mode=$MODE_PREF nr5g=$NR5G_MODE roam=$ROAM_PREF sim_detect=$SIM_DETECT"

    # --- Validate ---
    if [ "$SIM_SLOT" != "unset" ]; then
        case "$SIM_SLOT" in
            1|2) ;;
            *)
                cgi_error "invalid_sim_slot" "SIM slot must be 1 or 2"
                exit 0
                ;;
        esac
    fi

    if [ "$CFUN" != "unset" ]; then
        case "$CFUN" in
            0|1|4) ;;
            *)
                cgi_error "invalid_cfun" "CFUN must be 0, 1, or 4"
                exit 0
                ;;
        esac
    fi

    if [ "$MODE_PREF" != "unset" ]; then
        if ! rv_mode_pref "$MODE_PREF"; then
            cgi_error "$RV_CODE" "$RV_DETAIL"
            exit 0
        fi
    fi

    if [ "$NR5G_MODE" != "unset" ]; then
        case "$NR5G_MODE" in
            0|1|2) ;;
            *)
                cgi_error "invalid_nr5g_mode" "NR5G mode must be 0, 1, or 2"
                exit 0
                ;;
        esac
    fi

    if [ "$ROAM_PREF" != "unset" ]; then
        case "$ROAM_PREF" in
            1|3|255) ;;
            *)
                cgi_error "invalid_roam_pref" "Roaming preference must be 1, 3, or 255"
                exit 0
                ;;
        esac
    fi

    if [ "$SIM_DETECT" != "unset" ]; then
        case "$SIM_DETECT" in
            0|1) ;;
            *)
                cgi_error "invalid_sim_detect" "SIM detect must be 0 or 1"
                exit 0
                ;;
        esac
    fi

    # --- Apply in safe order: nr5g_mode, roam_pref, sim_detect, mode_pref, sim_slot (w/ CFUN procedure), cfun ---
    errors=""
    applied=""
    sim_cfun_restored=""
    sim_switch_verified=""

    # 1. NR5G mode (least disruptive, NVM write)
    if [ "$NR5G_MODE" != "unset" ]; then
        if at_write "AT+QNWPREFCFG=\"nr5g_disable_mode\",$NR5G_MODE"; then
            qlog_info "Set nr5g_disable_mode=$NR5G_MODE"
            applied="${applied}nr5g_mode,"
        else
            qlog_error "Failed to set nr5g_disable_mode=$NR5G_MODE (rc=$_aw_rc)"
            errors="${errors}nr5g_mode,"
        fi
        sleep "$CMD_GAP"
    fi

    # 2. Roaming preference (NVM write, takes effect immediately)
    if [ "$ROAM_PREF" != "unset" ]; then
        if at_write "AT+QNWPREFCFG=\"roam_pref\",$ROAM_PREF"; then
            qlog_info "Set roam_pref=$ROAM_PREF"
            applied="${applied}roam_pref,"
        else
            qlog_error "Failed to set roam_pref=$ROAM_PREF (rc=$_aw_rc)"
            errors="${errors}roam_pref,"
        fi
        sleep "$CMD_GAP"
    fi

    # 3. SIM detect (least disruptive, NVM write). insert_level is not
    #    user-exposed in this change — read the modem's current level back
    #    first and preserve it; only fall back to 1 when the read is empty
    #    (e.g. compound GET never ran / unsupported), so this write never
    #    silently resets a level someone set outside the UI.
    if [ "$SIM_DETECT" != "unset" ]; then
        sd_level="1"
        sd_read=$(qcmd 'AT+QSIMDET?' 2>/dev/null)
        sd_read_rc=$?
        # qcmd's failure contract (exit!=0 / stderr ERROR / empty stdout) means
        # rc, not just an empty grep match, is what tells a genuine read
        # failure (lock timeout, modem busy) apart from "line legitimately
        # absent". Only the latter is safe to paper over with sd_level=1 —
        # the former must abort the write, or we'd silently stomp a level the
        # user set outside this UI with a fabricated "1".
        if [ $sd_read_rc -ne 0 ]; then
            qlog_error "Failed to read AT+QSIMDET? before write (rc=$sd_read_rc); skipping sim_detect write to avoid clobbering insert_level"
            errors="${errors}sim_detect,"
        else
            sd_val=$(printf '%s\n' "$sd_read" | grep '+QSIMDET:' | head -1 | sed 's/+QSIMDET: //' | tr -d ' \r')
            if [ -n "$sd_val" ]; then
                sd_existing_level=$(printf '%s' "$sd_val" | cut -d',' -f2)
                [ -n "$sd_existing_level" ] && sd_level="$sd_existing_level"
            fi
            if at_write "AT+QSIMDET=$SIM_DETECT,$sd_level"; then
                qlog_info "Set sim_detect=$SIM_DETECT,$sd_level"
                applied="${applied}sim_detect,"
            else
                qlog_error "Failed to set sim_detect=$SIM_DETECT,$sd_level (rc=$_aw_rc)"
                errors="${errors}sim_detect,"
            fi
        fi
        sleep "$CMD_GAP"
    fi

    # 4. Network mode
    if [ "$MODE_PREF" != "unset" ]; then
        if radio_set_mode_pref "$MODE_PREF"; then
            qlog_info "Set mode_pref=$MODE_PREF"
            applied="${applied}mode_pref,"
        else
            qlog_error "Failed to set mode_pref=$MODE_PREF (rc=$_aw_rc)"
            errors="${errors}mode_pref,"
        fi
        sleep "$CMD_GAP"
    fi

    # 5. SIM slot change (CFUN=0 -> sleep 2 -> QUIMSLOT -> sleep 2 -> CFUN=1,
    #    then a read-back verification). AT+QUIMSLOT=N can return OK while the
    #    modem silently STAYS on the old slot under qcmd lock contention;
    #    trusting that OK would auto-apply the wrong SIM's profile. So the
    #    write is verified via AT+QUIMSLOT? (verify_quimslot, slot_verify.sh),
    #    retried once on mismatch, and only a VERIFIED switch fires the
    #    downstream side effects (sim_db registration, auto-apply, refresh).
    #    This is a radio cycle (CFUN=0/1), not a full modem reboot — the
    #    LAN/HTTP path survives, so it's safe to run inline in this CGI.
    if [ "$SIM_SLOT" != "unset" ]; then
        qlog_info "SIM slot change: starting CFUN=0 -> QUIMSLOT=$SIM_SLOT -> CFUN=1 procedure"
        sim_proceed="1"

        # Step 1: Switch to minimum functionality
        # (at_write, not the dead `*ERROR*` stdout match — see the at_write
        # comment above. qcmd's failure signal is exit status, never stdout.)
        if ! at_write "AT+CFUN=0"; then
            sim_proceed=""
        fi

        if [ -z "$sim_proceed" ]; then
            qlog_error "SIM procedure: CFUN=0 failed (rc=$_aw_rc)"
            errors="${errors}sim_slot,"
        else
            qlog_info "SIM procedure: CFUN=0 OK"
            sleep 2

            # Step 2: Change SIM slot. The write's own accept/reject is only
            # logged here — verify_quimslot below (Step 4) is the sole
            # authority on whether the switch actually applied, per the
            # comment block above this procedure.
            if at_write "AT+QUIMSLOT=$SIM_SLOT"; then
                qlog_info "SIM procedure: QUIMSLOT=$SIM_SLOT accepted (pending read-back)"
            else
                qlog_error "SIM procedure: QUIMSLOT=$SIM_SLOT failed (rc=$_aw_rc)"
            fi
            sleep 2

            # Step 3: Restore full functionality
            if at_write "AT+CFUN=1"; then
                qlog_info "SIM procedure: CFUN=1 restored"
                sim_cfun_restored="1"
            else
                qlog_error "SIM procedure: CFUN=1 restore failed (rc=$_aw_rc)"
            fi

            # Step 4: Read-back verification. AT+QUIMSLOT? becomes readable
            # shortly after CFUN=1, before full SIM init.
            sim_switch_verified=$(verify_quimslot "$SIM_SLOT")

            if [ -z "$sim_switch_verified" ]; then
                # One full-discipline retry of the write, then re-verify.
                qlog_warn "SIM procedure: QUIMSLOT read-back != $SIM_SLOT after 10 tries; retrying write once"
                qcmd 'AT+CFUN=0' >/dev/null 2>&1
                sleep 2
                qcmd "AT+QUIMSLOT=$SIM_SLOT" >/dev/null 2>&1
                sleep 2
                if at_write 'AT+CFUN=1'; then
                    sim_cfun_restored="1"
                else
                    qlog_error "SIM procedure: CFUN=1 restore (retry) failed (rc=$_aw_rc)"
                fi
                sim_switch_verified=$(verify_quimslot "$SIM_SLOT")
            fi

            if [ -n "$sim_switch_verified" ]; then
                qlog_info "SIM procedure: QUIMSLOT=$SIM_SLOT verified active"
                applied="${applied}sim_slot,"

                # Auto-apply matching profile for the new SIM (verified switch only)
                sleep 1  # let SIM initialize after CFUN=1
                _new_iccid=$(qcmd 'AT+QCCID' 2>/dev/null | grep '+QCCID:' | sed 's/+QCCID: //g' | tr -d '\r ')
                if [ -n "$_new_iccid" ]; then
                    # Register the switched-to SIM in the known-SIMs database so
                    # the Known SIMs count reflects it immediately. A deliberate
                    # slot switch is an expected SIM (like a watchdog failover),
                    # not a physical swap to alert on — this also suppresses a
                    # redundant "New SIM" toast on the next poller boot.
                    ( . /usr/lib/qmanager/sim_db.sh 2>/dev/null && sim_db_add "$_new_iccid" )
                    . /usr/lib/qmanager/profile_mgr.sh 2>/dev/null
                    auto_apply_profile "$_new_iccid" "sim_switch"
                fi
                # Nudge the poller to refresh warm fields (carrier name,
                # SIM slot, APN, phone number) on its next ~2s tick.
                touch /tmp/qmanager_tier2_refresh 2>/dev/null || true
            else
                qlog_error "SIM procedure: QUIMSLOT=$SIM_SLOT NOT verified after retry — modem stayed on old slot"
                errors="${errors}sim_slot,"
            fi
        fi
    fi

    # 6. CFUN change (skip if SIM procedure already restored to user's desired value)
    if [ "$CFUN" != "unset" ]; then
        if [ -n "$sim_cfun_restored" ] && [ "$CFUN" = "1" ]; then
            # SIM slot procedure already set CFUN=1
            qlog_info "CFUN=1 already applied by SIM slot procedure"
            applied="${applied}cfun,"
        else
            sleep "$CMD_GAP"
            if at_write "AT+CFUN=$CFUN"; then
                qlog_info "Set CFUN=$CFUN"
                applied="${applied}cfun,"
            else
                qlog_error "Failed to set CFUN=$CFUN (rc=$_aw_rc)"
                errors="${errors}cfun,"
            fi
        fi
    fi

    # --- Response ---
    if [ -z "$errors" ]; then
        cgi_success
    else
        jq -n --arg errors "$errors" --arg applied "$applied" \
            '{
                success: false,
                error: "partial_failure",
                failed_fields: ($errors | split(",") | map(select(length > 0))),
                applied_fields: ($applied | split(",") | map(select(length > 0)))
            }'
    fi
    exit 0
fi

# --- Method not allowed -------------------------------------------------------
cgi_method_not_allowed
