#!/bin/sh
# =============================================================================
# email_alerts.sh — Email Alert Library for QManager
# =============================================================================
# Sourced by qmanager_poller and CGI scripts. Provides config parsing, msmtp
# transport, and NDJSON logging for the email channel. Downtime tracking and
# threshold evaluation now live in alert_engine.sh (the unified alert
# engine) — this library only knows how to SEND, not when to send.
#
# Dependencies: jq, msmtp, qlog_* functions (optional)
# Install location: /usr/lib/qmanager/email_alerts.sh
#
# Config:  /etc/qmanager/email_alerts.json
# Log:     /tmp/qmanager_email_log.json (NDJSON, max 100 entries)
# msmtp:   /etc/qmanager-secrets/msmtprc (0600 root:root, rendered by the
#          qmanager_secret_set root helper on save). The whole directory is
#          0700 root:root, so ONLY root-context callers (the poller / alert
#          engine) can read it — the plaintext Gmail app password lives inside
#          it and is deliberately out of www-data's reach.
# Reload:  /tmp/qmanager_email_reload (flag file, touched by CGI, consumed
#          by alert_engine.sh's check_alerts)
# =============================================================================

[ -n "$_EMAIL_ALERTS_LOADED" ] && return 0
_EMAIL_ALERTS_LOADED=1

# Single alert wait resolver (cq_alert_after_min); optional, falls back to the channel key.
[ -f "${QM_LIB_DIR:-/usr/lib/qmanager}/conn_state.sh" ] && . "${QM_LIB_DIR:-/usr/lib/qmanager}/conn_state.sh"

# --- Constants ---------------------------------------------------------------
_EA_CONFIG="/etc/qmanager/email_alerts.json"
_EA_MSMTP_CONFIG="/etc/qmanager-secrets/msmtprc"
_EA_LOG_FILE="/tmp/qmanager_email_log.json"
_EA_RELOAD_FLAG="/tmp/qmanager_email_reload"
_EA_MAX_LOG=100

# Detect msmtp binary — Entware installs to /opt/bin which is not in the
# poller's PATH. Check common locations so both CGI and daemon contexts work.
_EA_MSMTP_BIN=""
for _p in /opt/bin/msmtp /usr/bin/msmtp; do
    if [ -x "$_p" ]; then
        _EA_MSMTP_BIN="$_p"
        break
    fi
done

# --- State (populated by email_alerts_init / _ea_read_config) ----------------
_ea_enabled="false"
_ea_sender=""
_ea_recipient=""
# NOTE: there is deliberately no _ea_app_password any more. The password is not
# in email_alerts.json at all — msmtp reads it out of the root-only msmtprc, so
# this library never needs to hold the plaintext. What remains in the JSON is
# the non-secret marker below.
_ea_app_password_set="false"
_ea_threshold_minutes=5

# =============================================================================
# _ea_read_config — Read settings from config JSON
# =============================================================================
_ea_read_config() {
    if [ ! -f "$_EA_CONFIG" ]; then
        _ea_enabled="false"
        return 1
    fi

    _ea_enabled=$(jq -r '(.enabled) | if . == null then "false" else tostring end' "$_EA_CONFIG" 2>/dev/null)
    _ea_sender=$(jq -r '.sender_email // ""' "$_EA_CONFIG" 2>/dev/null)
    _ea_recipient=$(jq -r '.recipient_email // ""' "$_EA_CONFIG" 2>/dev/null)
    _ea_app_password_set=$(jq -r '(.app_password_set) | if . == true then "true" else "false" end' "$_EA_CONFIG" 2>/dev/null)
    _ea_threshold_minutes=$(jq -r '.threshold_minutes // 5' "$_EA_CONFIG" 2>/dev/null)
    # The wait is one value owned by Connection Quality; the per-channel key is a fallback.
    if command -v cq_alert_after_min >/dev/null 2>&1; then
        cq_alert_after_min
        _ea_threshold_minutes="$CQ_ALERT_AFTER_MIN"
    fi

    # Validate
    if [ "$_ea_enabled" != "true" ]; then
        _ea_enabled="false"
        return 0
    fi
    # "Do we have a password?" is now answered by the marker the root helper
    # maintains, not by reading the secret itself. (Before the relocation this
    # tested $_ea_app_password; leaving it that way would have silently forced
    # _ea_enabled=false on every device once the plaintext left the JSON.)
    if [ -z "$_ea_sender" ] || [ -z "$_ea_recipient" ] || [ "$_ea_app_password_set" != "true" ]; then
        _ea_enabled="false"
        return 1
    fi
    return 0
}

# =============================================================================
# email_alerts_init — Called once at poller startup
# =============================================================================
# No longer called by the poller (alert_engine_init replaces it) — kept as a
# standalone entry point for manual sourcing/testing of this lib in isolation.
email_alerts_init() {
    _ea_read_config
    if [ "$_ea_enabled" = "true" ]; then
        qlog_info "Email alerts enabled: sender=$_ea_sender recipient=$_ea_recipient threshold=${_ea_threshold_minutes}m"
    else
        qlog_info "Email alerts disabled or not configured"
    fi
}

# =============================================================================
# email_alert_send — Send a one-shot alert email (used by alert_engine.sh
# and by the CGI's send_test action)
# =============================================================================
# Single attempt, no retry/stabilize delay — the caller decides whether this
# needs to run in the background (alert_engine.sh dispatches inline within
# the poll cycle; CGI test-sends call this directly and wait for the result).
# Returns msmtp's exit code (0 = sent).
email_alert_send() {
    local subject="$1"
    local body="$2"
    local html

    if [ -z "$_EA_MSMTP_BIN" ] || [ ! -x "$_EA_MSMTP_BIN" ]; then
        qlog_error "Email alerts: msmtp not installed"
        return 1
    fi

    html=$(_ea_build_generic_html "$subject" "$body")
    _ea_do_send "$subject" "$html"
}

# =============================================================================
# _ea_send_test_email — Send a test email (called by CGI)
# =============================================================================
_ea_send_test_email() {
    local html
    html=$(_ea_build_test_html)

    if _ea_do_send "Test Alert" "$html"; then
        _ea_log_event "test" "sent" "$_ea_recipient"
        return 0
    else
        _ea_log_event "test" "failed" "$_ea_recipient"
        return 1
    fi
}

# =============================================================================
# _ea_do_send — Core msmtp send function
# =============================================================================
_ea_do_send() {
    local subject="$1"
    local html_body="$2"

    if [ -z "$_EA_MSMTP_BIN" ] || [ ! -x "$_EA_MSMTP_BIN" ]; then
        qlog_error "Email alerts: msmtp not installed"
        return 1
    fi

    if [ ! -f "$_EA_MSMTP_CONFIG" ]; then
        qlog_error "Email alerts: msmtp config not found at $_EA_MSMTP_CONFIG"
        return 1
    fi

    {
        printf "From: %s\r\n" "$_ea_sender"
        printf "To: %s\r\n" "$_ea_recipient"
        printf "Subject: [QManager] %s\r\n" "$subject"
        printf "MIME-Version: 1.0\r\n"
        printf "Content-Type: text/html; charset=UTF-8\r\n"
        printf "\r\n"
        printf "%s" "$html_body"
    } | "$_EA_MSMTP_BIN" -C "$_EA_MSMTP_CONFIG" "$_ea_recipient" 2>/tmp/msmtp_last_err.log

    local rc=$?
    if [ $rc -eq 0 ]; then
        qlog_info "Email alerts: email sent successfully to $_ea_recipient"
    else
        local err_detail
        err_detail=$(cat /tmp/msmtp_last_err.log 2>/dev/null)
        qlog_error "Email alerts: msmtp failed (rc=$rc): $err_detail"
    fi
    return $rc
}

# =============================================================================
# _ea_log_event — Append entry to NDJSON log file
# =============================================================================
# /tmp OWNERSHIP — see docs/reference/tmp-file-ownership.md.
#
# /tmp is root:root 1777 with fs.protected_regular=1, and that sysctl blocks
# ROOT from writing a www-data-owned file there (not the other way round, which
# is the part everyone gets backwards). /tmp/qmanager_email_log.json is NOT
# seeded by qmanager_setup, so whoever creates it first owns it for the boot.
#
# Every writer of this file is now root: the alert engine runs in the poller,
# and the CGI's test send was moved behind qmanager_email_send when msmtprc
# became root-only. www-data only ever READS it (alerts.sh's get_log), so a
# root-created 0644 file is exactly right and no seed is needed.
#
# That makes the trim below safe, but it is written to the doc's rules anyway,
# because "root is the only writer" is a property a future change can quietly
# break: the scratch name is PID-qualified (a fixed `.tmp` in sticky /tmp can
# strand an unwritable, un-unlinkable leftover) and the result is copied THROUGH
# the existing inode instead of renamed over it (rename(2) swaps in a new inode
# and would discard the original's ownership).
_ea_log_event() {
    local trigger="$1"
    local status="$2"
    local recipient="$3"
    local ts
    ts=$(date "+%Y-%m-%d %H:%M:%S")

    jq -n -c \
        --arg ts "$ts" \
        --arg trigger "$trigger" \
        --arg status "$status" \
        --arg recipient "$recipient" \
        '{timestamp: $ts, trigger: $trigger, status: $status, recipient: $recipient}' \
        >> "$_EA_LOG_FILE"

    # Trim to max entries
    local count
    count=$(wc -l < "$_EA_LOG_FILE" 2>/dev/null || echo 0)
    if [ "$count" -gt "$_EA_MAX_LOG" ]; then
        local tmp="${_EA_LOG_FILE}.tmp.$$"
        if tail -n "$_EA_MAX_LOG" "$_EA_LOG_FILE" > "$tmp" 2>/dev/null; then
            cat "$tmp" > "$_EA_LOG_FILE" 2>/dev/null
        fi
        rm -f "$tmp"
    fi
}

# =============================================================================
# _ea_format_duration — Convert seconds to human-readable string
# =============================================================================
_ea_format_duration() {
    local secs="$1"
    local hours
    local mins
    local remaining

    hours=$((secs / 3600))
    remaining=$((secs % 3600))
    mins=$((remaining / 60))
    remaining=$((remaining % 60))

    if [ "$hours" -gt 0 ]; then
        printf "%dh %dm %ds" "$hours" "$mins" "$remaining"
    elif [ "$mins" -gt 0 ]; then
        printf "%dm %ds" "$mins" "$remaining"
    else
        printf "%ds" "$remaining"
    fi
}

# =============================================================================
# HTML Email Templates
# =============================================================================
# Table-based layout with inline styles for maximum email client compatibility.
# No external resources — fully self-contained.
# =============================================================================

_EA_COLOR_PRIMARY="#4338ca"
_EA_COLOR_SUCCESS="#22c55e"
_EA_COLOR_BG="#f4f4f5"
_EA_COLOR_WHITE="#ffffff"
_EA_COLOR_TEXT="#18181b"
_EA_COLOR_MUTED="#71717a"
_EA_FONT="'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif"

# --- Shared wrapper (header + footer) ----------------------------------------

_ea_html_header() {
    local subtitle="$1"
    cat <<HTMLEOF
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0;padding:0;background-color:${_EA_COLOR_BG};font-family:${_EA_FONT};">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:${_EA_COLOR_BG};padding:32px 16px;">
<tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;">

<!-- Header -->
<tr><td style="background-color:${_EA_COLOR_PRIMARY};padding:24px 32px;border-radius:10px 10px 0 0;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
  <tr>
    <td style="color:${_EA_COLOR_WHITE};font-size:20px;font-weight:700;letter-spacing:-0.3px;">QManager</td>
  </tr>
  <tr>
    <td style="color:rgba(255,255,255,0.75);font-size:13px;padding-top:4px;">${subtitle}</td>
  </tr>
  </table>
</td></tr>

<!-- Content card -->
<tr><td style="background-color:${_EA_COLOR_WHITE};padding:32px;border-radius:0 0 10px 10px;">
HTMLEOF
}

_ea_html_footer() {
    cat <<HTMLEOF
</td></tr>

<!-- Footer -->
<tr><td style="padding:24px 32px;text-align:center;">
  <p style="margin:0 0 4px;font-size:12px;color:${_EA_COLOR_MUTED};">QManager &middot; Quectel Modem Management</p>
  <p style="margin:0;font-size:11px;color:${_EA_COLOR_MUTED};">You received this because email alerts are enabled on your device.</p>
</td></tr>

</table>
</td></tr></table>
</body>
</html>
HTMLEOF
}

# --- Generic alert email (connection_restored / reboot / connection_lost) ----
# Single shared template for every alert_engine.sh-dispatched trigger. Badge
# label/color is chosen from the trigger keyword so recovery vs. reboot vs.
# a generic alert are visually distinct without needing a template per event.

_ea_build_generic_html() {
    local subject="$1"
    local body="$2"
    local badge_label="ALERT"
    local badge_color="$_EA_COLOR_PRIMARY"

    case "$subject" in
        *Recovered*) badge_label="RECOVERED"; badge_color="$_EA_COLOR_SUCCESS" ;;
        *Rebooted*)  badge_label="REBOOT";    badge_color="$_EA_COLOR_PRIMARY" ;;
    esac

    {
        _ea_html_header "QManager Alert"

        cat <<HTMLEOF
  <!-- Badge -->
  <table role="presentation" cellpadding="0" cellspacing="0"><tr>
    <td style="background-color:${badge_color};color:${_EA_COLOR_WHITE};font-size:12px;font-weight:600;padding:4px 12px;border-radius:20px;letter-spacing:0.3px;">${badge_label}</td>
  </tr></table>

  <!-- Headline -->
  <h1 style="margin:16px 0 8px;font-size:18px;font-weight:600;color:${_EA_COLOR_TEXT};">${subject}</h1>
  <p style="margin:0;font-size:14px;color:${_EA_COLOR_TEXT};line-height:1.5;">${body}</p>
HTMLEOF

        _ea_html_footer
    }
}

# --- Test email ---------------------------------------------------------------

_ea_build_test_html() {
    {
        _ea_html_header "Test Notification"

        cat <<HTMLEOF
  <!-- Badge -->
  <table role="presentation" cellpadding="0" cellspacing="0"><tr>
    <td style="background-color:${_EA_COLOR_PRIMARY};color:${_EA_COLOR_WHITE};font-size:12px;font-weight:600;padding:4px 12px;border-radius:20px;letter-spacing:0.3px;">TEST</td>
  </tr></table>

  <!-- Headline -->
  <h1 style="margin:16px 0 8px;font-size:18px;font-weight:600;color:${_EA_COLOR_TEXT};">Your email alert configuration is working</h1>
  <p style="margin:0 0 4px;font-size:14px;color:${_EA_COLOR_MUTED};line-height:1.5;">This was a test email triggered from the QManager dashboard. Your email alert settings are correctly configured and ready to send notifications.</p>

  <p style="margin:20px 0 0;font-size:13px;color:${_EA_COLOR_MUTED};line-height:1.5;">No action is needed.</p>
HTMLEOF

        _ea_html_footer
    }
}
