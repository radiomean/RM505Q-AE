#!/bin/sh
# Install a display-only LTE-anchor summary on QManager's Antenna Statistics page.
# Designed for the RM505Q-AE's NSA behaviour: QENG has LTE aggregate values while
# QRSRP/QRSRQ/QSINR may return NR5G ports only.
set -eu

web_root=/usrdata/qmanager/www
page="$web_root/cellular/antenna-statistics/index.html"
asset="$web_root/rm505q-lte-anchor-summary.js"
marker='rm505q-lte-anchor-summary.js'
backup_dir=/usrdata/qmanager/rm505q-lte-anchor-ui-backup

[ -f "$page" ] || {
    echo "QManager Antenna Statistics page was not found: $page" >&2
    exit 1
}

mkdir -p "$backup_dir"
cp -p "$page" "$backup_dir/index.html.before-rm505q-lte-anchor-ui"

cp rm505q-lte-anchor-summary.js "$asset"
chmod 0644 "$asset"

if ! grep -q "$marker" "$page"; then
    tmp="$page.rm505q-lte-anchor-ui.$$"
    sed 's#</body>#<script src="/rm505q-lte-anchor-summary.js"></script></body>#' "$page" > "$tmp"
    mv "$tmp" "$page"
fi

echo "Installed RM505Q LTE-anchor summary. Back-up: $backup_dir"
echo "Hard-refresh QManager's Cellular > Antenna Statistics page."
